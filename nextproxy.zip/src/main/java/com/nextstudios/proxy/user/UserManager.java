package com.nextstudios.proxy.user;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.EventTask;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.storage.PlayerSettings;
import com.nextstudios.proxy.util.Names;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class UserManager {
    private final NextProxy plugin;
    private final Map<UUID, User> users = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> cooldownStore = new ConcurrentHashMap<>();

    public UserManager(NextProxy plugin) {
        this.plugin = plugin;
    }

    public void reload() {
    }

    public User get(Player player) {
        User existing = users.get(player.getUniqueId());
        if (existing != null) {
            return existing;
        }
        if (!player.isActive()) {
            return new User(player);
        }
        return users.computeIfAbsent(player.getUniqueId(), id -> new User(player, cooldownsOf(id)));
    }

    private Map<String, Long> cooldownsOf(UUID id) {
        return cooldownStore.computeIfAbsent(id, key -> new ConcurrentHashMap<>());
    }

    public Optional<User> find(UUID uuid) {
        return Optional.ofNullable(users.get(uuid));
    }

    public Collection<User> all() {
        return users.values();
    }

    @Subscribe
    public EventTask onLogin(LoginEvent event) {
        if (!event.getResult().isAllowed()) {
            return null;
        }
        Player player = event.getPlayer();
        User user = new User(player, cooldownsOf(player.getUniqueId()));
        users.put(player.getUniqueId(), user);
        String ip = Names.ipOf(player);
        boolean recordIp = this.plugin.isModuleEnabled("ip") && this.plugin.moduleConfig("ip").getBoolean("record-history", true);
        CompletableFuture<PlayerSettings> load = this.plugin.database().query(connection -> {
            this.plugin.playerRepository().recordLogin(connection, user.uuid(), user.name(), ip, System.currentTimeMillis(), recordIp);
            return this.plugin.playerRepository().loadSettings(connection, user.uuid());
        }).thenApply(settings -> {
            user.apply(settings);
            return settings;
        }).exceptionally(error -> {
            this.plugin.logger().error("Impossibile caricare i dati di {} dal database: uso i valori di default", user.name(), error);
            return null;
        });
        return EventTask.resumeWhenComplete(load);
    }

    @Subscribe(priority = -32767)
    public void onDisconnect(DisconnectEvent event) {
        Player player = event.getPlayer();
        users.computeIfPresent(player.getUniqueId(), (id, user) -> {
            if (user.player() != player) {
                return user;
            }
            return null;
        });
        long now = System.currentTimeMillis();
        cooldownStore.computeIfPresent(player.getUniqueId(), (id, map) -> {
            map.values().removeIf(until -> until <= now);
            return map.isEmpty() ? null : map;
        });
    }

    public void save(User user) {
        this.plugin.playerRepository().saveSettings(user.uuid(), user.settings()).exceptionally(error -> {
            this.plugin.logger().error("Impossibile salvare le impostazioni di {}", user.name(), error);
            return null;
        });
    }

    public String displayName(Player target, CommandSource viewer) {
        return target.getUsername();
    }

    public Optional<Player> find(CommandSource viewer, String input) {
        if (input == null || input.isEmpty() || input.length() > 32) {
            return Optional.empty();
        }
        return this.plugin.proxy().getPlayer(input);
    }

    public List<String> suggest(CommandSource viewer, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        ArrayList<String> result = new ArrayList<>();
        for (Player player : this.plugin.proxy().getAllPlayers()) {
            String name = displayName(player, viewer);
            if (!name.toLowerCase(Locale.ROOT).startsWith(lower)) {
                continue;
            }
            result.add(name);
        }
        result.sort(String.CASE_INSENSITIVE_ORDER);
        return result;
    }
}
