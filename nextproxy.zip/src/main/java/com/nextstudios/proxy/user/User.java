package com.nextstudios.proxy.user;

import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.storage.PlayerSettings;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class User {
    private final Player player;
    private final Map<String, Long> cooldowns;
    private volatile boolean staffLogs = true;

    public User(Player player) {
        this(player, new ConcurrentHashMap<>());
    }

    public User(Player player, Map<String, Long> cooldowns) {
        this.player = player;
        this.cooldowns = cooldowns;
    }

    public Map<String, Long> cooldowns() {
        return this.cooldowns;
    }

    public Player player() {
        return this.player;
    }

    public UUID uuid() {
        return this.player.getUniqueId();
    }

    public String name() {
        return this.player.getUsername();
    }

    public boolean staffLogs() {
        return staffLogs;
    }

    public void staffLogs(boolean value) {
        staffLogs = value;
    }

    public PlayerSettings settings() {
        return new PlayerSettings(staffLogs);
    }

    public void apply(PlayerSettings settings) {
        staffLogs = settings.staffLogs();
    }

    public long tryCooldown(String key, long millis) {
        if (millis <= 0L) {
            return 0L;
        }
        long now = System.currentTimeMillis();
        long[] remaining = new long[]{0L};
        this.cooldowns.compute(key, (k, until) -> {
            if (until != null && until > now) {
                remaining[0] = until - now;
                return until;
            }
            return now + millis;
        });
        return remaining[0];
    }
}
