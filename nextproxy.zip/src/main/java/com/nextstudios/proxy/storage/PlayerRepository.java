package com.nextstudios.proxy.storage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class PlayerRepository {
    private final Database db;

    public PlayerRepository(Database db) {
        this.db = db;
    }

    public void recordLogin(Connection connection, UUID uuid, String name, String ip, long now, boolean recordIp) throws SQLException {
        String lower = name.toLowerCase(Locale.ROOT);
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("players") + " (uuid, name, name_lower, first_join, last_join, last_ip) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = ?, name_lower = ?, last_join = ?, last_ip = ?")) {
            statement.setString(1, uuid.toString());
            statement.setString(2, name);
            statement.setString(3, lower);
            statement.setLong(4, now);
            statement.setLong(5, now);
            statement.setString(6, ip);
            statement.setString(7, name);
            statement.setString(8, lower);
            statement.setLong(9, now);
            statement.setString(10, ip);
            statement.executeUpdate();
        }
        if (!recordIp) {
            return;
        }
        try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("ip_history") + " (uuid, ip, first_seen, last_seen, logins) VALUES (?, ?, ?, ?, 1) ON DUPLICATE KEY UPDATE last_seen = ?, logins = logins + 1")) {
            statement.setString(1, uuid.toString());
            statement.setString(2, ip);
            statement.setLong(3, now);
            statement.setLong(4, now);
            statement.setLong(5, now);
            statement.executeUpdate();
        }
    }

    public CompletableFuture<Optional<StoredPlayer>> findByName(String name) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT uuid, name, first_join, last_join, last_ip FROM " + this.db.table("players") + " WHERE name_lower = ? ORDER BY last_join DESC LIMIT 1")) {
                statement.setString(1, name.toLowerCase(Locale.ROOT));
                return readPlayer(statement);
            }
        });
    }

    public CompletableFuture<Optional<StoredPlayer>> findByUuid(UUID uuid) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT uuid, name, first_join, last_join, last_ip FROM " + this.db.table("players") + " WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                return readPlayer(statement);
            }
        });
    }

    private static Optional<StoredPlayer> readPlayer(PreparedStatement statement) throws SQLException {
        try (ResultSet rs = statement.executeQuery()) {
            if (!rs.next()) {
                return Optional.empty();
            }
            return Optional.of(new StoredPlayer(UUID.fromString(rs.getString(1)), rs.getString(2), rs.getLong(3), rs.getLong(4), rs.getString(5)));
        }
    }

    public CompletableFuture<List<IpEntry>> ipHistory(UUID uuid) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT ip, first_seen, last_seen, logins FROM " + this.db.table("ip_history") + " WHERE uuid = ? ORDER BY last_seen DESC")) {
                statement.setString(1, uuid.toString());
                ArrayList<IpEntry> result = new ArrayList<>();
                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        result.add(new IpEntry(rs.getString(1), rs.getLong(2), rs.getLong(3), rs.getInt(4)));
                    }
                }
                return result;
            }
        });
    }

    public CompletableFuture<List<IpAccount>> accountsByIp(String ip) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT h.uuid, p.name, h.last_seen, h.logins FROM " + this.db.table("ip_history") + " h LEFT JOIN " + this.db.table("players") + " p ON p.uuid = h.uuid WHERE h.ip = ? ORDER BY h.last_seen DESC")) {
                statement.setString(1, ip);
                ArrayList<IpAccount> result = new ArrayList<>();
                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        String name = rs.getString(2);
                        result.add(new IpAccount(UUID.fromString(rs.getString(1)), name == null ? "?" : name, rs.getLong(3), rs.getInt(4)));
                    }
                }
                return result;
            }
        });
    }

    public PlayerSettings loadSettings(Connection connection, UUID uuid) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT staff_logs FROM " + this.db.table("settings") + " WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet rs = statement.executeQuery()) {
                if (!rs.next()) {
                    return PlayerSettings.DEFAULTS;
                }
                return new PlayerSettings(rs.getBoolean(1));
            }
        }
    }

    public CompletableFuture<Void> saveSettings(UUID uuid, PlayerSettings settings) {
        return this.db.update(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("settings") + " (uuid, staff_logs) VALUES (?, ?) ON DUPLICATE KEY UPDATE staff_logs = ?")) {
                statement.setString(1, uuid.toString());
                statement.setBoolean(2, settings.staffLogs());
                statement.setBoolean(3, settings.staffLogs());
                statement.executeUpdate();
            }
        });
    }

    public record StoredPlayer(UUID uuid, String name, long firstJoin, long lastJoin, String lastIp) {
    }

    public record IpAccount(UUID uuid, String name, long lastSeen, int logins) {
    }

    public record IpEntry(String ip, long firstSeen, long lastSeen, int logins) {
    }
}
