package com.nextstudios.proxy.storage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class DataRepository {
    private final Database db;

    public DataRepository(Database db) {
        this.db = db;
    }

    public CompletableFuture<Optional<String>> get(String key) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT v FROM " + this.db.table("kv") + " WHERE k = ?")) {
                statement.setString(1, key);
                try (ResultSet rs = statement.executeQuery()) {
                    if (!rs.next()) {
                        return Optional.empty();
                    }
                    return Optional.ofNullable(rs.getString(1));
                }
            }
        });
    }

    public CompletableFuture<Void> set(String key, String value) {
        return this.db.update(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("kv") + " (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = ?")) {
                statement.setString(1, key);
                statement.setString(2, value);
                statement.setString(3, value);
                statement.executeUpdate();
            }
        });
    }

    public CompletableFuture<List<WhitelistEntry>> whitelist() {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT name, uuid FROM " + this.db.table("maintenance_whitelist") + " ORDER BY name_lower")) {
                ArrayList<WhitelistEntry> result = new ArrayList<>();
                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        String uuid = rs.getString(2);
                        result.add(new WhitelistEntry(rs.getString(1), uuid == null ? null : UUID.fromString(uuid)));
                    }
                }
                return result;
            }
        });
    }

    public CompletableFuture<Void> addWhitelist(String name, UUID uuid, long now) {
        return this.db.update(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("maintenance_whitelist") + " (name_lower, name, uuid, added_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = ?, uuid = ?")) {
                String id = uuid == null ? null : uuid.toString();
                statement.setString(1, name.toLowerCase(Locale.ROOT));
                statement.setString(2, name);
                statement.setString(3, id);
                statement.setLong(4, now);
                statement.setString(5, name);
                statement.setString(6, id);
                statement.executeUpdate();
            }
        });
    }

    public CompletableFuture<Boolean> removeWhitelist(String name) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("DELETE FROM " + this.db.table("maintenance_whitelist") + " WHERE name_lower = ?")) {
                statement.setString(1, name.toLowerCase(Locale.ROOT));
                return statement.executeUpdate() > 0;
            }
        });
    }

    public CompletableFuture<Map<String, Integer>> limits() {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT server, max_players FROM " + this.db.table("server_limits"))) {
                LinkedHashMap<String, Integer> result = new LinkedHashMap<>();
                try (ResultSet rs = statement.executeQuery()) {
                    while (rs.next()) {
                        result.put(rs.getString(1), rs.getInt(2));
                    }
                }
                return result;
            }
        });
    }

    public CompletableFuture<Void> setLimit(String server, int max) {
        return this.db.update(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("server_limits") + " (server, max_players) VALUES (?, ?) ON DUPLICATE KEY UPDATE max_players = ?")) {
                statement.setString(1, server);
                statement.setInt(2, max);
                statement.setInt(3, max);
                statement.executeUpdate();
            }
        });
    }

    public CompletableFuture<Boolean> removeLimit(String server) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("DELETE FROM " + this.db.table("server_limits") + " WHERE server = ?")) {
                statement.setString(1, server);
                return statement.executeUpdate() > 0;
            }
        });
    }

    public record WhitelistEntry(String name, UUID uuid) {
    }
}
