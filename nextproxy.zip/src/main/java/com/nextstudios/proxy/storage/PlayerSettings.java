package com.nextstudios.proxy.storage;

public record PlayerSettings(boolean staffLogs) {
    public static final PlayerSettings DEFAULTS = new PlayerSettings(true);
}
