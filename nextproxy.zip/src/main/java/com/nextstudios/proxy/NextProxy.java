package com.nextstudios.proxy;

import com.velocitypowered.api.command.Command;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.google.inject.Inject;
import com.nextstudios.proxy.command.CommandRegistry;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.config.Messages;
import com.nextstudios.proxy.config.ModuleConfig;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.broadcast.AutoBroadcastModule;
import com.nextstudios.proxy.module.custom.CustomCommandsModule;
import com.nextstudios.proxy.module.find.FindModule;
import com.nextstudios.proxy.module.hub.HubModule;
import com.nextstudios.proxy.module.ip.IpModule;
import com.nextstudios.proxy.module.maintenance.MaintenanceModule;
import com.nextstudios.proxy.module.motd.MotdModule;
import com.nextstudios.proxy.module.notes.NotesModule;
import com.nextstudios.proxy.module.playerlimit.PlayerLimitModule;
import com.nextstudios.proxy.module.pluginhider.PluginHiderModule;
import com.nextstudios.proxy.module.report.ReportModule;
import com.nextstudios.proxy.module.stafflogs.StaffLogsModule;
import com.nextstudios.proxy.module.teleport.GotoModule;
import com.nextstudios.proxy.module.webhook.WebhookService;
import com.nextstudios.proxy.module.webhook.WebhooksModule;
import com.nextstudios.proxy.storage.DataRepository;
import com.nextstudios.proxy.storage.Database;
import com.nextstudios.proxy.storage.NoteRepository;
import com.nextstudios.proxy.storage.PlayerRepository;
import com.nextstudios.proxy.user.UserManager;
import com.nextstudios.proxy.util.Names;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;

@Plugin(id = "nextproxy", name = "NextProxy", version = "1.0.0",
        description = "Core del network NextStudios: staff, report, manutenzione, MOTD, webhook e altro",
        authors = { "NextStudios" })
public final class NextProxy {
    public static final String VERSION = "1.0.0";
    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDirectory;
    private final List<Module> modules = new ArrayList<>();
    private volatile Map<String, ModuleConfig> moduleConfigs = Map.of();
    private volatile YamlConfig config;
    private volatile Messages messages;
    private Database database;
    private PlayerRepository playerRepository;
    private NoteRepository noteRepository;
    private DataRepository dataRepository;
    private CommandRegistry commands;
    private UserManager users;

    @Inject
    public NextProxy(ProxyServer proxy, Logger logger, @DataDirectory Path dataDirectory) {
        this.proxy = proxy;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onInitialize(ProxyInitializeEvent event) {
        long start = System.currentTimeMillis();
        try {
            Files.createDirectories(this.dataDirectory);
            loadCoreFiles();
            buildModules();
            moduleConfigs = loadModuleFiles();
            database = new Database(this.dataDirectory, config, this.logger);
            database.migrate();
            playerRepository = new PlayerRepository(database);
            noteRepository = new NoteRepository(database);
            dataRepository = new DataRepository(database);
            commands = new CommandRegistry(this);
            users = new UserManager(this);
            this.proxy.getEventManager().register(this, users);
            int enabled = enableModules();
            registerCoreCommand();
            this.logger.info("NextProxy v{} avviato in {}ms: {} moduli attivi, database {}",
                    new Object[] { VERSION, System.currentTimeMillis() - start, enabled, database.type() });
        } catch (Exception e) {
            this.logger.error("Impossibile avviare NextProxy: il plugin resta disattivato", e);
            shutdown();
        }
    }

    @Subscribe
    public void onShutdown(ProxyShutdownEvent event) {
        shutdown();
    }

    private void shutdown() {
        List<Module> reversed = new ArrayList<>(modules);
        Collections.reverse(reversed);
        for (Module module : reversed) {
            try {
                module.disable();
            } catch (RuntimeException e) {
                this.logger.error("Errore spegnendo il modulo {}", module.id(), e);
            }
        }
        modules.clear();
        if (commands != null) {
            commands.unregisterAll(this);
        }
        if (users != null) {
            this.proxy.getEventManager().unregisterListener(this, users);
        }
        if (database != null) {
            database.close();
            database = null;
        }
    }

    private void buildModules() {
        Collections.addAll(modules,
                new IpModule(this),
                new StaffLogsModule(this),
                new AutoBroadcastModule(this),
                new GotoModule(this),
                new HubModule(this),
                new ReportModule(this),
                new MaintenanceModule(this),
                new MotdModule(this),
                new PluginHiderModule(this),
                new CustomCommandsModule(this),
                new NotesModule(this),
                new PlayerLimitModule(this),
                new WebhooksModule(this),
                new FindModule(this));
    }

    private void loadCoreFiles() throws IOException {
        YamlConfig newConfig = YamlConfig.load(this.dataDirectory.resolve("config.yml"), "config.yml");
        YamlConfig newMessages = YamlConfig.load(this.dataDirectory.resolve("messages.yml"), "messages.yml");
        if (newConfig.contains("modules")) {
            this.logger.warn("config.yml contiene ancora la vecchia sezione 'modules': ora ogni funzione si configura in plugins/nextproxy/modules/ (la sezione viene ignorata)");
        }
        if (!Names.setNamePattern(newConfig.getString("general.name-pattern", "^[a-zA-Z0-9_.]{1,16}$"))) {
            this.logger.warn("general.name-pattern non è una regex valida: uso quella di default");
        }
        config = newConfig;
        messages = new Messages(newMessages, newConfig);
    }

    private Map<String, ModuleConfig> loadModuleFiles() throws IOException {
        Path directory = this.dataDirectory.resolve("modules");
        Files.createDirectories(directory);
        Map<String, ModuleConfig> loadedConfigs = new LinkedHashMap<>();
        for (Module module : modules) {
            ModuleConfig loaded;
            try {
                loaded = ModuleConfig.load(directory, module.id(), config, messages);
            } catch (IOException e) {
                this.logger.error("File modules/{}.yml non valido: il modulo resta disattivato", module.id(), e);
                loaded = ModuleConfig.disabled(module.id(), config, messages);
            }
            loadedConfigs.put(module.id(), loaded);
        }
        return Collections.unmodifiableMap(loadedConfigs);
    }

    private int enableModules() {
        int count = 0;
        for (Module module : modules) {
            if (!module.isConfiguredEnabled()) {
                continue;
            }
            try {
                module.enable();
                count++;
            } catch (RuntimeException e) {
                this.logger.error("Impossibile attivare il modulo {}: controlla modules/{}.yml", module.id(), module.id(), e);
            }
        }
        return count;
    }

    private void registerCoreCommand() {
        CommandSpec spec = CommandSpec.read(config.section("admin.commands.nextproxy"), "nextproxy");
        commands.register(this, spec, new CoreCommand(this, spec, messages));
    }

    public synchronized boolean reload() {
        if (database == null || commands == null || users == null) {
            this.logger.error("Reload impossibile: il plugin non è stato avviato correttamente");
            return false;
        }
        try {
            loadCoreFiles();
            moduleConfigs = loadModuleFiles();
        } catch (IOException e) {
            this.logger.error("Reload annullato: {}", e.getMessage());
            return false;
        }
        List<Module> reversed = new ArrayList<>(modules);
        Collections.reverse(reversed);
        for (Module module : reversed) {
            try {
                module.disable();
            } catch (RuntimeException e) {
                this.logger.error("Errore spegnendo il modulo {}", module.id(), e);
            }
        }
        commands.unregisterAll(this);
        users.reload();
        enableModules();
        registerCoreCommand();
        return true;
    }

    public ProxyServer proxy() {
        return this.proxy;
    }

    public Logger logger() {
        return this.logger;
    }

    public Path dataDirectory() {
        return this.dataDirectory;
    }

    public YamlConfig config() {
        return config;
    }

    public Messages messages() {
        return messages;
    }

    public YamlConfig moduleConfig(String id) {
        ModuleConfig module = moduleConfigs.get(id);
        return module != null ? module.settings() : YamlConfig.empty();
    }

    public Messages moduleMessages(String id) {
        ModuleConfig module = moduleConfigs.get(id);
        return module != null ? module.messages() : messages;
    }

    public Database database() {
        return database;
    }

    public PlayerRepository playerRepository() {
        return playerRepository;
    }

    public NoteRepository noteRepository() {
        return noteRepository;
    }

    public DataRepository dataRepository() {
        return dataRepository;
    }

    public CommandRegistry commands() {
        return commands;
    }

    public UserManager users() {
        return users;
    }

    public List<Module> modules() {
        return Collections.unmodifiableList(modules);
    }

    public boolean isModuleEnabled(String id) {
        for (Module module : modules) {
            if (!module.id().equals(id)) {
                continue;
            }
            return module.isEnabled();
        }
        return false;
    }

    public <T extends Module> T module(Class<T> type) {
        for (Module module : modules) {
            if (!type.isInstance(module)) {
                continue;
            }
            return type.cast(module);
        }
        return null;
    }

    public WebhookService webhooks() {
        WebhooksModule module = module(WebhooksModule.class);
        return module != null && module.isEnabled() ? module.service() : null;
    }

    public String consoleName() {
        return config.getString("general.console-name", "Console");
    }

    public String nameOf(CommandSource source) {
        if (source instanceof Player) {
            return ((Player)source).getUsername();
        }
        return consoleName();
    }

    public boolean canUseColors(CommandSource source) {
        String permission = config.getString("general.color-permission", "nextproxy.chat.color");
        return !permission.isEmpty() && source.hasPermission(permission);
    }
}
