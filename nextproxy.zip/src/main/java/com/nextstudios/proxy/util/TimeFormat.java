package com.nextstudios.proxy.util;

import com.nextstudios.proxy.config.YamlConfig;
import java.time.DateTimeException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public final class TimeFormat {
    private final String days;
    private final String hours;
    private final String minutes;
    private final String seconds;
    private final String now;
    private final String agoTemplate;
    private final String never;
    private final DateTimeFormatter dateFormat;

    public TimeFormat(YamlConfig messages, YamlConfig config) {
        DateTimeFormatter formatter;
        ZoneId zone;
        days = messages.getString("time.days", "g");
        hours = messages.getString("time.hours", "h");
        minutes = messages.getString("time.minutes", "m");
        seconds = messages.getString("time.seconds", "s");
        now = messages.getString("time.now", "adesso");
        agoTemplate = messages.getString("time.ago", "<time> fa");
        never = messages.getString("time.never", "mai");
        try {
            zone = ZoneId.of(config.getString("general.timezone", "Europe/Rome"));
        }
        catch (DateTimeException e) {
            zone = ZoneId.systemDefault();
        }
        try {
            formatter = DateTimeFormatter.ofPattern(config.getString("general.date-format", "dd/MM/yyyy HH:mm"));
        }
        catch (IllegalArgumentException e) {
            formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        }
        dateFormat = formatter.withZone(zone);
    }

    public String duration(long millis) {
        long total = Math.max(0L, (millis + 999L) / 1000L);
        if (total == 0L) {
            return "0" + seconds;
        }
        long[] values = new long[]{total / 86400L, total % 86400L / 3600L, total % 3600L / 60L, total % 60L};
        String[] units = {days, hours, minutes, seconds};
        StringBuilder out = new StringBuilder();
        int parts = 0;
        for (int i = 0; i < values.length && parts < 2; i++) {
            if (values[i] <= 0L) continue;
            if (out.length() > 0) {
                out.append(' ');
            }
            out.append(values[i]).append(units[i]);
            parts++;
        }
        return out.toString();
    }

    public String date(long epochMillis) {
        return epochMillis <= 0L ? never : dateFormat.format(Instant.ofEpochMilli(epochMillis));
    }

    public String ago(long epochMillis) {
        if (epochMillis <= 0L) {
            return never;
        }
        long diff = System.currentTimeMillis() - epochMillis;
        return diff < 1000L ? now : agoTemplate.replace("<time>", duration(diff));
    }
}
