package com.nextstudios.proxy.util;

import java.util.List;

public final class Pages {
    private Pages() {
    }

    public static int count(int total, int size) {
        return Math.max(1, (total + size - 1) / size);
    }

    public static <T> List<T> slice(List<T> list, int page, int size) {
        int safePage = Math.max(1, Math.min(page, count(list.size(), size)));
        int from = (safePage - 1) * size;
        return from >= list.size() ? List.of() : list.subList(from, Math.min(list.size(), from + size));
    }

    public static int clamp(int page, int total, int size) {
        return Math.max(1, Math.min(page, count(total, size)));
    }
}
