package com.nextstudios.proxy.util;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public final class DiscordWebhook {

    private static final HttpClient CLIENT = HttpClient.newHttpClient();
    private static final int MAX_RETRIES = 3;

    private DiscordWebhook() {}

    public static CompletableFuture<Void> send(String webhookUrl, String username, String avatarUrl, Embed... embeds) {
        return post(webhookUrl, username, avatarUrl, null, embeds).thenApply(status -> null);
    }

    public static CompletableFuture<Integer> post(String webhookUrl, String username, String avatarUrl, String content, Embed... embeds) {
        return post(webhookUrl, username, avatarUrl, content, Duration.ofSeconds(10), embeds);
    }

    public static CompletableFuture<Integer> post(String webhookUrl, String username, String avatarUrl, String content, Duration timeout, Embed... embeds) {
        if (!isValidUrl(webhookUrl)) {
            return CompletableFuture.completedFuture(0);
        }

        StringBuilder json = new StringBuilder("{");
        if (username != null && !username.isBlank()) {
            json.append("\"username\":").append(escapeJson(username)).append(",");
        }
        if (avatarUrl != null && !avatarUrl.isBlank()) {
            json.append("\"avatar_url\":").append(escapeJson(avatarUrl)).append(",");
        }

        boolean hasEmbeds = embeds != null && embeds.length > 0;
        if (hasEmbeds) {
            json.append("\"embeds\":[");
            for (int i = 0; i < embeds.length; i++) {
                if (i > 0) json.append(",");
                json.append(embeds[i].toJson());
            }
            json.append("]");
            if (content != null) {
                json.append(",");
            }
        }
        if (content != null) {
            json.append("\"content\":").append(escapeJson(content));
        } else if (!hasEmbeds) {
            json.append("\"content\":\"\"");
        }
        json.append("}");

        HttpRequest request;
        try {
            request = HttpRequest.newBuilder()
                    .uri(URI.create(webhookUrl.trim()))
                    .timeout(timeout == null || timeout.isNegative() || timeout.isZero() ? Duration.ofSeconds(10) : timeout)
                    .header("Content-Type", "application/json")
                    .header("User-Agent", "NextProxy-DiscordWebhook")
                    .POST(HttpRequest.BodyPublishers.ofString(json.toString()))
                    .build();
        } catch (IllegalArgumentException e) {
            return CompletableFuture.completedFuture(0);
        }

        return send(request, 0);
    }

    private static CompletableFuture<Integer> send(HttpRequest request, int attempt) {
        return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .thenCompose(response -> {
                    int status = response.statusCode();
                    if (status == 429 && attempt < MAX_RETRIES) {
                        long delay = retryAfterMillis(response);
                        return CompletableFuture.supplyAsync(() -> status, CompletableFuture.delayedExecutor(delay, TimeUnit.MILLISECONDS))
                                .thenCompose(ignored -> send(request, attempt + 1));
                    }
                    return CompletableFuture.completedFuture(status);
                })
                .exceptionally(err -> -1);
    }

    private static long retryAfterMillis(HttpResponse<?> response) {
        String value = response.headers().firstValue("Retry-After")
                .or(() -> response.headers().firstValue("X-RateLimit-Reset-After"))
                .orElse("1");
        try {
            double seconds = Double.parseDouble(value.trim());
            return Math.max(100L, Math.min(10000L, (long) (seconds * 1000.0)));
        } catch (NumberFormatException e) {
            return 1000L;
        }
    }

    public static boolean isValidUrl(String url) {
        if (url == null || url.isBlank()) {
            return false;
        }
        try {
            URI uri = URI.create(url.trim());
            String scheme = uri.getScheme();
            return scheme != null
                    && (scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http"))
                    && uri.getHost() != null;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static String escapeJson(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        sb.append("\"");
        return sb.toString();
    }

    public static class Embed {
        private String title;
        private String description;
        private int color = 0x5865F2;
        private String footer;
        private Instant timestamp;
        private final List<Field> fields = new ArrayList<>();

        public Embed title(String title) {
            this.title = title;
            return this;
        }

        public Embed description(String description) {
            this.description = description;
            return this;
        }

        public Embed color(int color) {
            this.color = color;
            return this;
        }

        public Embed footer(String footer) {
            this.footer = footer;
            return this;
        }

        public Embed timestamp(Instant timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Embed addField(String name, String value, boolean inline) {
            fields.add(new Field(name, value, inline));
            return this;
        }

        String toJson() {
            StringBuilder sb = new StringBuilder("{");
            if (title != null) sb.append("\"title\":").append(escapeJson(title)).append(",");
            if (description != null) sb.append("\"description\":").append(escapeJson(description)).append(",");
            sb.append("\"color\":").append(color).append(",");

            if (footer != null) {
                sb.append("\"footer\":{\"text\":").append(escapeJson(footer)).append("},");
            }
            if (timestamp != null) {
                sb.append("\"timestamp\":").append(escapeJson(timestamp.toString())).append(",");
            }

            if (!fields.isEmpty()) {
                sb.append("\"fields\":[");
                for (int i = 0; i < fields.size(); i++) {
                    if (i > 0) sb.append(",");
                    Field f = fields.get(i);
                    sb.append("{\"name\":").append(escapeJson(f.name))
                      .append(",\"value\":").append(escapeJson(f.value))
                      .append(",\"inline\":").append(f.inline).append("}");
                }
                sb.append("]");
            } else if (sb.charAt(sb.length() - 1) == ',') {
                sb.setLength(sb.length() - 1);
            }
            if (sb.charAt(sb.length() - 1) == ',') {
                sb.setLength(sb.length() - 1);
            }
            sb.append("}");
            return sb.toString();
        }

        private record Field(String name, String value, boolean inline) {}
    }
}
