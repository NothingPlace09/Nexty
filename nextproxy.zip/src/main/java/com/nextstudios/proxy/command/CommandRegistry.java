package com.nextstudios.proxy.command;

import com.velocitypowered.api.command.Command;
import com.velocitypowered.api.command.CommandManager;
import com.velocitypowered.api.command.CommandMeta;
import com.nextstudios.proxy.NextProxy;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public final class CommandRegistry {
    private final NextProxy plugin;
    private final Map<Object, List<CommandMeta>> byOwner = new ConcurrentHashMap<>();

    public CommandRegistry(NextProxy plugin) {
        this.plugin = plugin;
    }

    public void register(Object owner, CommandSpec spec, Command command) {
        CommandManager manager = this.plugin.proxy().getCommandManager();
        CommandMeta meta = manager.metaBuilder(spec.name()).aliases(spec.aliases().toArray(new String[0])).plugin(this.plugin).build();
        manager.register(meta, command);
        byOwner.computeIfAbsent(owner, key -> new CopyOnWriteArrayList()).add(meta);
    }

    public void unregisterAll(Object owner) {
        List<CommandMeta> metas = byOwner.remove(owner);
        if (metas == null) {
            return;
        }
        CommandManager manager = this.plugin.proxy().getCommandManager();
        for (CommandMeta meta : metas) {
            manager.unregister(meta);
        }
    }
}
