package com.nextstudios.proxy.command;

import com.velocitypowered.api.command.CommandSource;
import com.nextstudios.proxy.config.YamlConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public record CommandSpec(String name, List<String> aliases, String permission) {
    private static final Pattern NAME = Pattern.compile("^[a-z0-9_\\-]{1,32}$");

    public static CommandSpec read(YamlConfig section, String fallbackName) {
        String name = section.getString("name", fallbackName).trim().toLowerCase(Locale.ROOT);
        if (!NAME.matcher(name).matches()) {
            throw new IllegalArgumentException("Nome di comando non valido: '" + name + "'");
        }
        ArrayList<String> aliases = new ArrayList<>();
        for (String raw : section.getStringList("aliases")) {
            String alias = raw.trim().toLowerCase(Locale.ROOT);
            if (!NAME.matcher(alias).matches() || alias.equals(name) || aliases.contains(alias)) continue;
            aliases.add(alias);
        }
        return new CommandSpec(name, List.copyOf(aliases), section.getString("permission", "").trim());
    }

    public boolean allows(CommandSource source) {
        return this.permission.isEmpty() || source.hasPermission(this.permission);
    }
}
