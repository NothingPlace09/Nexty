package com.nextstudios.proxy.config;

import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.SafeConstructor;
import org.yaml.snakeyaml.error.YAMLException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class YamlConfig {
    private final Map<String, Object> values;
    private final Map<String, Object> defaults;

    private YamlConfig(Map<String, Object> values, Map<String, Object> defaults) {
        this.values = values;
        this.defaults = defaults;
    }

    public static YamlConfig of(Map<String, Object> values) {
        return new YamlConfig(new LinkedHashMap<>(values), Collections.emptyMap());
    }

    public static YamlConfig empty() {
        return new YamlConfig(Collections.emptyMap(), Collections.emptyMap());
    }

    public static YamlConfig load(Path file, String resource) throws IOException {
        byte[] bundled;
        try (InputStream in = YamlConfig.class.getClassLoader().getResourceAsStream(resource)) {
            if (in == null) {
                throw new IOException("Risorsa mancante nel jar: " + resource);
            }
            bundled = in.readAllBytes();
        }
        if (Files.notExists(file)) {
            Files.createDirectories(file.getParent());
            Files.write(file, bundled);
        }
        Map<String, Object> defaults = parse(new String(bundled, StandardCharsets.UTF_8), resource);
        Map<String, Object> values = parse(Files.readString(file, StandardCharsets.UTF_8), file.getFileName().toString());
        return new YamlConfig(values, defaults);
    }

    public static YamlConfig loadOptional(Path file, String resource) throws IOException {
        try (InputStream in = YamlConfig.class.getClassLoader().getResourceAsStream(resource)) {
            if (in == null) {
                return empty();
            }
        }
        return load(file, resource);
    }

    private static Map<String, Object> parse(String content, String source) throws IOException {
        Object loaded;
        LoaderOptions options = new LoaderOptions();
        options.setAllowDuplicateKeys(false);
        options.setMaxAliasesForCollections(50);
        Yaml yaml = new Yaml(new SafeConstructor(options));
        try {
            loaded = yaml.load(content);
        }
        catch (YAMLException e) {
            throw new IOException("Errore di sintassi in " + source + ": " + e.getMessage(), e);
        }
        if (loaded == null) {
            return new LinkedHashMap<>();
        }
        if (!(loaded instanceof Map)) {
            throw new IOException(source + ": la radice del file deve essere una sezione");
        }
        Map map = (Map)loaded;
        return normalize(map);
    }

    private static Map<String, Object> normalize(Map<?, ?> map) {
        LinkedHashMap<String, Object> result = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            result.put(String.valueOf(entry.getKey()), normalizeValue(entry.getValue()));
        }
        return result;
    }

    private static Object normalizeValue(Object value) {
        if (value instanceof Map map) {
            return normalize(map);
        }
        if (value instanceof List list) {
            ArrayList<Object> result = new ArrayList<>(list.size());
            for (Object element : list) {
                result.add(normalizeValue(element));
            }
            return result;
        }
        return value;
    }

    public YamlConfig section(String path) {
        return new YamlConfig(asMap(find(this.values, path)), asMap(find(this.defaults, path)));
    }

    public Object get(String path) {
        Object value = find(this.values, path);
        return value != null ? value : find(this.defaults, path);
    }

    public boolean contains(String path) {
        return get(path) != null;
    }

    public String getString(String path, String def) {
        Object value = get(path);
        return value == null || value instanceof Map || value instanceof List ? def : String.valueOf(value);
    }

    public int getInt(String path, int def) {
        return (int)getLong(path, def);
    }

    public long getLong(String path, long def) {
        Object value = get(path);
        if (value instanceof Number number) {
            return number.longValue();
        }
        if (value instanceof String text) {
            try {
                return Long.parseLong(text.trim());
            }
            catch (NumberFormatException ignored) {
                return def;
            }
        }
        return def;
    }

    public boolean getBoolean(String path, boolean def) {
        Object value = get(path);
        if (value instanceof Boolean bool) {
            return bool;
        }
        if (value instanceof String text) {
            return Boolean.parseBoolean(text.trim());
        }
        return def;
    }

    public List<String> getStringList(String path) {
        Object value = get(path);
        if (value instanceof List list) {
            ArrayList<String> result = new ArrayList<>(list.size());
            for (Object element : list) {
                if (element == null) continue;
                result.add(String.valueOf(element));
            }
            return result;
        }
        if (value instanceof String text) {
            return List.of(text);
        }
        return List.of();
    }

    public List<Object> getList(String path) {
        Object value = get(path);
        if (value instanceof List list) {
            return Collections.unmodifiableList(new ArrayList(list));
        }
        return List.of();
    }

    public Set<String> getKeys(String path) {
        Object user = find(this.values, path);
        if (user instanceof Map map) {
            return keysOf(map);
        }
        return keysOf(asMap(find(this.defaults, path)));
    }

    private static Set<String> keysOf(Map<?, ?> map) {
        LinkedHashSet<String> keys = new LinkedHashSet<>();
        for (Object key : map.keySet()) {
            keys.add(String.valueOf(key));
        }
        return keys;
    }

    private static Object find(Map<String, Object> root, String path) {
        if (path.isEmpty()) {
            return root;
        }
        Object current = root;
        for (String part : path.split("\\.")) {
            if (!(current instanceof Map)) {
                return null;
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) current;
            current = map.get(part);
            if (current != null) continue;
            return null;
        }
        return current;
    }

    private static Map<String, Object> asMap(Object value) {
        return value instanceof Map ? (Map)value : Map.of();
    }
}
