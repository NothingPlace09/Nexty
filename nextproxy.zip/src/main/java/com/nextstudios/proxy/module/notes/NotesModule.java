package com.nextstudios.proxy.module.notes;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.webhook.WebhookService;
import com.nextstudios.proxy.storage.NoteRepository;

import com.nextstudios.proxy.util.Names;
import com.nextstudios.proxy.util.Pages;
import com.nextstudios.proxy.util.Text;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class NotesModule
extends Module {
    private static final int PAGE_SIZE = 8;
    private static final List<String> SUBCOMMANDS = List.of("add", "remove", "list");
    private boolean alertOnJoin;
    private String alertPermission;
    private int maxLength;

    public NotesModule(NextProxy plugin) {
        super(plugin, "notes");
    }

    @Override
    protected void onEnable() {
        alertOnJoin = config().getBoolean("alert-on-join", true);
        alertPermission = config().getString("alert-permission", "NextProxy.notes.alert");
        maxLength = Math.max(1, Math.min(512, config().getInt("max-length", 256)));
        listen(this);
        command("notes", spec -> new NotesCommand(spec));
    }

    @Subscribe
    public void onPostLogin(PostLoginEvent event) {
        if (!alertOnJoin || alertPermission.isEmpty()) {
            return;
        }
        Player player = event.getPlayer();
        this.plugin.noteRepository().count(player.getUniqueId()).thenAccept(count -> {
            if (count <= 0) {
                return;
            }
            for (Player staff : proxy().getAllPlayers()) {
                if (staff.equals(player) || !staff.hasPermission(alertPermission)) continue;
                messages().send(staff, "join-alert", Text.token("player", users().displayName(player, staff)), Text.token("count", count));
            }
        }).exceptionally(error -> {
            logger().error("Impossibile contare le note di {}", player.getUsername(), error);
            return null;
        });
    }

    private final class NotesCommand
    extends BaseCommand {
        NotesCommand(CommandSpec spec) {
            super(NotesModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (args.length < 2) {
                messages().send(source, "help");
                return;
            }
            String input = args[1];
            if (!Names.isValidName(input)) {
                messages().send(source, "general.invalid-name", Text.literal("input", input));
                return;
            }
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "add": {
                    String text = NotesCommand.join(args, 2);
                    if (text.isEmpty()) {
                        messages().send(source, "help");
                        break;
                    }
                    if (text.length() > NotesModule.this.maxLength) {
                        messages().send(source, "too-long", Text.token("max", NotesModule.this.maxLength));
                        break;
                    }
                    withTarget(source, input, target -> add(source, (Target)target, text));
                    break;
                }
                case "remove": {
                    long id = args.length == 3 ? parseId(args[2]) : -1L;
                    if (id <= 0L) {
                        messages().send(source, "help");
                        break;
                    }
                    withTarget(source, input, target -> remove(source, (Target)target, id));
                    break;
                }
                case "list": {
                    int page = args.length >= 3 ? NotesCommand.parsePositive(args[2], 1) : 1;
                    withTarget(source, input, target -> list(source, (Target)target, page));
                    break;
                }
                default: {
                    messages().send(source, "help");
                }
            }
        }

        private long parseId(String input) {
            try {
                return Long.parseLong(input.startsWith("#") ? input.substring(1) : input);
            }
            catch (NumberFormatException e) {
                return -1L;
            }
        }

        private void withTarget(CommandSource source, String input, Consumer<Target> action) {
            Optional<Player> online = users().find(source, input);
            CompletableFuture<Optional<Target>> target = online.isPresent() ? CompletableFuture.completedFuture(Optional.of(new Target(online.get().getUniqueId(), users().displayName(online.get(), source)))) : this.plugin.playerRepository().findByName(input).thenApply(found -> found.map(stored -> new Target(stored.uuid(), stored.name())));
            target.thenAccept(found -> found.ifPresentOrElse(action, () -> messages().send(source, "general.player-unknown", Text.token("player", input)))).exceptionally(error -> fail(source, error));
        }

        private void add(CommandSource source, Target target, String text) {
            UUID author = source instanceof Player ? ((Player)source).getUniqueId() : null;
            String authorName = this.plugin.nameOf(source);
            this.plugin.noteRepository().add(target.uuid(), author, authorName, text, System.currentTimeMillis()).thenAccept(id -> {
                messages().send(source, "added", Text.token("id", id), Text.token("player", target.name()));
                WebhookService hooks = this.plugin.webhooks();
                if (hooks != null) {
                    hooks.note(authorName, target.name(), text);
                }
            }).exceptionally(error -> fail(source, error));
        }

        private void remove(CommandSource source, Target target, long id) {
            this.plugin.noteRepository().remove(target.uuid(), id).thenAccept(removed -> messages().send(source, removed ? "removed" : "not-found", Text.token("id", id), Text.token("player", target.name()))).exceptionally(error -> fail(source, error));
        }

        private void list(CommandSource source, Target target, int page) {
            this.plugin.noteRepository().list(target.uuid()).thenAccept(notes -> {
                if (notes.isEmpty()) {
                    messages().send(source, "list-empty", Text.token("player", target.name()));
                    return;
                }
                int current = Pages.clamp(page, notes.size(), 8);
                messages().send(source, "list-header", Text.token("player", target.name()), Text.token("count", notes.size()));
                for (NoteRepository.Note note : Pages.slice(notes, current, 8)) {
                    messages().send(source, "list-entry", Text.token("id", note.id()), Text.literal("note", note.text()), Text.literal("author", note.authorName()), Text.literal("date", messages().time().date(note.createdAt())), Text.token("player", target.name()));
                }
                int pages = Pages.count(notes.size(), 8);
                if (pages > 1) {
                    messages().send(source, "general.page", Text.token("page", current), Text.token("pages", pages));
                }
            }).exceptionally(error -> fail(source, error));
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length <= 1) {
                return NotesCommand.filter(SUBCOMMANDS, args.length == 0 ? "" : args[0]);
            }
            if (args.length == 2) {
                return users().suggest(source, args[1]);
            }
            return List.of();
        }
    }

    private record Target(UUID uuid, String name) {
    }
}
