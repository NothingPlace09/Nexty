package com.nextstudios.proxy.module.custom;

import com.velocitypowered.api.command.CommandSource;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class CustomCommandsModule
extends Module {
    public CustomCommandsModule(NextProxy plugin) {
        super(plugin, "customcommands");
    }

    @Override
    protected void onEnable() {
        for (String key : config().getKeys("commands")) {
            String message = String.join("\n", config().getStringList("commands." + key + ".message"));
            try {
                command(key, spec -> new InfoCommand(spec, message));
            }
            catch (IllegalArgumentException e) {
                logger().warn("Comando personalizzato '{}' ignorato: {}", key, e.getMessage());
            }
        }
    }

    private final class InfoCommand
    extends BaseCommand {
        private final String message;

        InfoCommand(CommandSpec spec, String message) {
            super(CustomCommandsModule.this, spec);
            this.message = message;
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (!this.message.isEmpty()) {
                source.sendMessage(messages().parse(this.message));
            }
        }
    }
}
