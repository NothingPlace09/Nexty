package com.nextstudios.proxy.module.hub;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.util.Text;

public final class HubModule
extends Module {
    private String serverName;

    public HubModule(NextProxy plugin) {
        super(plugin, "hub");
    }

    @Override
    protected void onEnable() {
        serverName = config().getString("server", "lobby");
        command("hub", spec -> new HubCommand(spec));
    }

    private final class HubCommand
    extends BaseCommand {
        HubCommand(CommandSpec spec) {
            super(HubModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            Player player = requirePlayer(source);
            if (player == null) {
                return;
            }
            RegisteredServer target = HubModule.this.proxy().getServer(HubModule.this.serverName).orElse(null);
            if (target == null) {
                messages().send(source, "general.server-not-found", Text.token("server", HubModule.this.serverName));
                return;
            }
            String name = target.getServerInfo().getName();
            if (player.getCurrentServer().map(connection -> connection.getServer().equals(target)).orElse(false)) {
                messages().send(source, "already-connected", Text.token("server", name));
                return;
            }
            messages().send(source, "connecting", Text.token("server", name));
            player.createConnectionRequest(target).fireAndForget();
        }
    }
}
