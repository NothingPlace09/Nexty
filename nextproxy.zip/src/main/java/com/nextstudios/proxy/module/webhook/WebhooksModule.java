package com.nextstudios.proxy.module.webhook;

import com.velocitypowered.api.command.CommandSource;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.util.Text;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class WebhooksModule extends Module {
    private static final List<String> SUBCOMMANDS = List.of("test", "on", "off", "status");
    private static final String STATE_KEY = "webhooks.active";
    private final WebhookService service;

    public WebhooksModule(NextProxy plugin) {
        super(plugin, "webhooks");
        service = new WebhookService(plugin);
    }

    public WebhookService service() {
        return service;
    }

    @Override
    protected void onEnable() {
        service.load(config());
        this.plugin.dataRepository().get(STATE_KEY).thenAccept(stored -> {
            if (stored.isPresent()) {
                service.setActive(Boolean.parseBoolean(stored.get()));
            }
        }).exceptionally(error -> {
            logger().error("Impossibile leggere lo stato dei webhook", error);
            return null;
        });
        if (!service.isConfigured()) {
            logger().warn("Webhooks attivi ma webhook-url è vuoto: imposta la URL del canale in modules/webhooks.yml (Impostazioni del canale > Integrazioni > Webhook)");
        } else {
            logger().info("Webhook Discord configurato: embed per {}", String.join(", ", config().getKeys("events")));
        }
        command("webhooks", spec -> new WebhooksCommand(spec));
    }

    private void setActive(boolean value, CommandSource source) {
        service.setActive(value);
        this.plugin.dataRepository().set(STATE_KEY, Boolean.toString(value)).exceptionally(error -> {
            logger().error("Impossibile salvare lo stato dei webhook", error);
            return null;
        });
        messages().send(source, value ? "enabled" : "disabled");
    }

    private final class WebhooksCommand extends BaseCommand {
        WebhooksCommand(CommandSpec spec) {
            super(WebhooksModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            String sub = args.length == 0 ? "status" : args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "test" -> {
                    if (!WebhooksModule.this.service.isConfigured()) {
                        messages().send(source, "not-configured");
                        return;
                    }
                    WebhooksModule.this.service.test();
                    messages().send(source, "sent-test");
                }
                case "on" -> {
                    if (WebhooksModule.this.service.isActive()) {
                        messages().send(source, "already-enabled");
                        return;
                    }
                    if (!WebhooksModule.this.service.isConfigured()) {
                        messages().send(source, "not-configured");
                        return;
                    }
                    WebhooksModule.this.setActive(true, source);
                }
                case "off" -> {
                    if (!WebhooksModule.this.service.isActive()) {
                        messages().send(source, "already-disabled");
                        return;
                    }
                    WebhooksModule.this.setActive(false, source);
                }
                default -> messages().send(source, "status",
                        Text.component("state", messages().get(WebhooksModule.this.service.isActive() ? "state-on" : "state-off")),
                        Text.token("url", WebhooksModule.this.service.isConfigured() ? "impostata" : "mancante"),
                        Text.literal("events", String.join(", ", WebhooksModule.this.config().getKeys("events"))));
            }
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            return args.length <= 1 ? filter(SUBCOMMANDS, args.length == 0 ? "" : args[0]) : List.of();
        }
    }
}
