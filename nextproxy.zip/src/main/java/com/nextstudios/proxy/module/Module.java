package com.nextstudios.proxy.module;

import com.velocitypowered.api.command.Command;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.scheduler.ScheduledTask;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.config.Messages;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.user.UserManager;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import org.slf4j.Logger;

public abstract class Module {
    protected final NextProxy plugin;
    private final String id;
    private final List<Object> listeners = new ArrayList<>();
    private final List<ScheduledTask> tasks = new ArrayList<>();
    private volatile boolean enabled;

    protected Module(NextProxy plugin, String id) {
        this.plugin = plugin;
        this.id = id;
    }

    public final String id() {
        return this.id;
    }

    public final boolean isEnabled() {
        return enabled;
    }

    public final boolean isConfiguredEnabled() {
        return this.plugin.moduleConfig(this.id).getBoolean("enabled", true);
    }

    public final NextProxy plugin() {
        return this.plugin;
    }

    public final Messages messages() {
        return this.plugin.moduleMessages(this.id);
    }

    public final synchronized void enable() {
        if (enabled) {
            return;
        }
        try {
            onEnable();
            enabled = true;
        }
        catch (RuntimeException e) {
            cleanup();
            throw e;
        }
    }

    public final synchronized void disable() {
        if (!enabled) {
            return;
        }
        enabled = false;
        try {
            onDisable();
        }
        finally {
            cleanup();
        }
    }

    private void cleanup() {
        for (Object listener : listeners) {
            this.plugin.proxy().getEventManager().unregisterListener(this.plugin, listener);
        }
        listeners.clear();
        for (ScheduledTask task : tasks) {
            task.cancel();
        }
        tasks.clear();
        this.plugin.commands().unregisterAll(this);
    }

    protected abstract void onEnable();

    protected void onDisable() {
    }

    protected YamlConfig config() {
        return this.plugin.moduleConfig(this.id);
    }

    protected UserManager users() {

        return this.plugin.users();
    }

    protected ProxyServer proxy() {
        return this.plugin.proxy();
    }

    protected Logger logger() {
        return this.plugin.logger();
    }

    protected void listen(Object listener) {
        this.plugin.proxy().getEventManager().register(this.plugin, listener);
        listeners.add(listener);
    }

    protected CommandSpec spec(String key) {
        return CommandSpec.read(config().section("commands." + key), key);
    }

    protected void command(String key, Function<CommandSpec, ? extends Command> factory) {
        CommandSpec spec = spec(key);
        this.plugin.commands().register(this, spec, factory.apply(spec));
    }

    protected void repeat(long delay, long period, TimeUnit unit, Runnable task) {
        Runnable safe = () -> {
            try {
                task.run();
            }
            catch (RuntimeException e) {
                logger().error("Errore in un task del modulo {}", this.id, e);
            }
        };
        tasks.add(this.plugin.proxy().getScheduler().buildTask(this.plugin, safe).delay(delay, unit).repeat(period, unit).schedule());
    }
}
