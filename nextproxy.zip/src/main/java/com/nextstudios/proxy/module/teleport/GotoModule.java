package com.nextstudios.proxy.module.teleport;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.util.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.kyori.adventure.audience.Audience;

public final class GotoModule
extends Module {
    private boolean perServerPermission;
    private boolean allowPlayerTarget;

    public GotoModule(NextProxy plugin) {
        super(plugin, "goto");
    }

    @Override
    protected void onEnable() {
        perServerPermission = config().getBoolean("per-server-permission", false);
        allowPlayerTarget = config().getBoolean("allow-player-target", true);
        command("goto", spec -> new GotoCommand(spec));
    }

    private final class GotoCommand
    extends BaseCommand {
        GotoCommand(CommandSpec spec) {
            super(GotoModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            Optional<Player> other;
            Player player = requirePlayer(source);
            if (player == null) {
                return;
            }
            if (args.length != 1) {
                messages().usage(source, "usage");
                return;
            }
            String input = args[0];
            RegisteredServer target = GotoModule.this.proxy().getServer(input).orElse(null);
            if (target == null && GotoModule.this.allowPlayerTarget && (other = users().find(player, input)).isPresent() && (target = other.get().getCurrentServer().map(ServerConnection::getServer).orElse(null)) == null) {
                messages().send(source, "player-no-server", Text.token("player", users().displayName(other.get(), player)));
                return;
            }
            if (target == null) {
                messages().send(source, "general.server-not-found", Text.token("server", input));
                return;
            }
            String name = target.getServerInfo().getName();
            if (GotoModule.this.perServerPermission && !player.hasPermission("NextProxy.goto.server." + name.toLowerCase(Locale.ROOT))) {
                messages().send(source, "no-permission-server", Text.token("server", name));
                return;
            }
            RegisteredServer destination = target;
            if (player.getCurrentServer().map(connection -> connection.getServer().equals(destination)).orElse(false)) {
                messages().send(source, "already-connected", Text.token("server", name));
                return;
            }
            messages().send(source, "connecting", Text.token("server", name));
            player.createConnectionRequest(destination).fireAndForget();
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length > 1) {
                return List.of();
            }
            String input = args.length == 0 ? "" : args[0];
            ArrayList<String> options = new ArrayList<>();
            for (RegisteredServer server : GotoModule.this.proxy().getAllServers()) {
                options.add(server.getServerInfo().getName());
            }
            List<String> result = GotoCommand.filter(options, input);
            if (GotoModule.this.allowPlayerTarget) {
                result.addAll(users().suggest(source, input));
            }
            return result;
        }
    }
}
