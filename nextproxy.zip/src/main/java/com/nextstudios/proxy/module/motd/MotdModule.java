package com.nextstudios.proxy.module.motd;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyPingEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.ServerPing;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.maintenance.MaintenanceModule;
import com.nextstudios.proxy.util.Text;
import java.util.List;
import java.util.Locale;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class MotdModule extends Module {
    private static final List<String> SUBCOMMANDS = List.of("set", "version", "preview", "reset");
    private String line1;
    private String line2;
    private String version;
    private int protocol;
    private boolean hidePlayers;
    private int maxPlayers;
    private String permission;

    public MotdModule(NextProxy plugin) {
        super(plugin, "motd");
    }

    @Override
    protected void onEnable() {
        permission = config().getString("commands.motd.permission", "nextproxy.motd");
        readConfig();
        this.plugin.dataRepository().get("motd.line1").thenAccept(value -> {
            if (value.isPresent() && !value.get().isEmpty()) {
                this.line1 = value.get();
            }
        }).exceptionally(error -> null);
        this.plugin.dataRepository().get("motd.line2").thenAccept(value -> {
            if (value.isPresent() && !value.get().isEmpty()) {
                this.line2 = value.get();
            }
        }).exceptionally(error -> null);
        this.plugin.dataRepository().get("motd.version").thenAccept(value -> {
            if (value.isPresent()) {
                version = value.get();
            }
        }).exceptionally(error -> null);
        listen(this);
        command("motd", spec -> new MotdCommand(spec));
    }

    private void readConfig() {
        this.line1 = config().getString("line1", "");
        this.line2 = config().getString("line2", "");
        version = config().getString("version", "");
        protocol = config().getInt("version-protocol", -1);
        hidePlayers = config().getBoolean("hide-players", false);
        maxPlayers = config().getInt("max-players", -1);
    }

    @Subscribe
    public void onPing(ProxyPingEvent event) {
        YamlConfig maintenance = maintenancePing();
        boolean maintenanceActive = maintenance != null;
        String first = maintenanceActive ? maintenance.getString("line1", "") : this.line1;
        String second = maintenanceActive ? maintenance.getString("line2", "") : this.line2;
        String versionText = maintenanceActive ? maintenance.getString("version", "<red>Manutenzione") : version;

        TagResolver[] resolvers = new TagResolver[] {
            Text.token("online", proxy().getPlayerCount()),
            Text.token("max", maxPlayers >= 0 ? maxPlayers : proxy().getConfiguration().getShowMaxPlayers()),
            Text.token("version", proxy().getVersion().getVersion())
        };

        ServerPing.Builder builder = event.getPing().asBuilder()
                .description(messages().parse(first + "\n" + second, resolvers));
        if (!versionText.isEmpty()) {
            builder.version(new ServerPing.Version(protocol, Text.legacySection(messages().parse(versionText, resolvers))));
        }
        if (hidePlayers || maintenanceActive && maintenance.getBoolean("hide-players", false)) {
            builder.nullPlayers();
        }
        if (maxPlayers >= 0) {
            builder.onlinePlayers(proxy().getPlayerCount()).maximumPlayers(maxPlayers);
        }
        event.setPing(builder.build());
    }

    private YamlConfig maintenancePing() {
        MaintenanceModule maintenance = this.plugin.module(MaintenanceModule.class);
        if (maintenance == null || !maintenance.isEnabled() || !maintenance.isActive()) {
            return null;
        }
        YamlConfig section = this.plugin.moduleConfig("maintenance").section("ping");
        return section.getBoolean("enabled", true) && section.contains("line1") ? section : null;
    }

    private void save(String key, String value) {
        this.plugin.dataRepository().set(key, value).exceptionally(error -> {
            logger().error("Impossibile salvare il MOTD", error);
            return null;
        });
    }

    private final class MotdCommand extends BaseCommand {
        MotdCommand(CommandSpec spec) {
            super(MotdModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            String sub = args.length == 0 ? "preview" : args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "set" -> set(source, args);
                case "version" -> version(source, args);
                case "reset" -> reset(source);
                default -> preview(source);
            }
        }

        private void set(CommandSource source, String[] args) {
            if (args.length < 3 || (!args[1].equals("1") && !args[1].equals("2"))) {
                messages().usage(source, "usage-set");
                return;
            }
            String text = join(args, 2);
            if (text.isEmpty()) {
                messages().usage(source, "usage-set");
                return;
            }
            if (args[1].equals("1")) {
                MotdModule.this.line1 = text;
                MotdModule.this.save("motd.line1", text);
            } else {
                MotdModule.this.line2 = text;
                MotdModule.this.save("motd.line2", text);
            }
            messages().send(source, "line-updated", Text.token("line", args[1]));
            preview(source);
        }

        private void version(CommandSource source, String[] args) {
            if (args.length < 2) {
                messages().usage(source, "usage-version");
                return;
            }
            MotdModule.this.version = join(args, 1);
            MotdModule.this.save("motd.version", MotdModule.this.version);
            messages().send(source, "version-updated", Text.literal("version", MotdModule.this.version));
        }

        private void reset(CommandSource source) {
            MotdModule.this.readConfig();
            MotdModule.this.save("motd.line1", "");
            MotdModule.this.save("motd.line2", "");
            MotdModule.this.save("motd.version", "");
            messages().send(source, "reset");
            preview(source);
        }

        private void preview(CommandSource source) {
            TagResolver[] resolvers = new TagResolver[] {
                Text.token("online", MotdModule.this.proxy().getPlayerCount()),
                Text.token("max", MotdModule.this.maxPlayers >= 0 ? MotdModule.this.maxPlayers : MotdModule.this.proxy().getConfiguration().getShowMaxPlayers()),
                Text.token("version", MotdModule.this.proxy().getVersion().getVersion())
            };
            Component line1 = MotdModule.this.messages().parse(MotdModule.this.line1, resolvers);
            Component line2 = MotdModule.this.messages().parse(MotdModule.this.line2, resolvers);
            messages().send(source, "preview-header");
            source.sendMessage(line1);
            source.sendMessage(line2);
            for (Player player : MotdModule.this.proxy().getAllPlayers()) {
                if (!player.hasPermission(MotdModule.this.permission)) {
                    continue;
                }
                messages().send(player, "preview-updated", Text.token("player", MotdModule.this.plugin.nameOf(source)));
            }
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length <= 1) {
                return filter(SUBCOMMANDS, args.length == 0 ? "" : args[0]);
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
                return filter(List.of("1", "2"), args[1]);
            }
            return List.of();
        }
    }
}
