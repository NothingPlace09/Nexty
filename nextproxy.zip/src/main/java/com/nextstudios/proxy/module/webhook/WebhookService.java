package com.nextstudios.proxy.module.webhook;

import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.util.DiscordWebhook;
import com.nextstudios.proxy.util.Text;
import com.velocitypowered.api.proxy.Player;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class WebhookService {
    private static final int DEFAULT_COLOR = 0x5865F2;
    private static final int MAX_FIELD = 1024;
    private final NextProxy plugin;
    private volatile Map<String, Boolean> events = Map.of();
    private volatile Map<String, Integer> colors = Map.of();
    private volatile Map<String, String> titles = Map.of();
    private volatile String url;
    private volatile String username;
    private volatile String avatarUrl;
    private volatile String footer;
    private volatile boolean notifyInGame;
    private volatile boolean reportIncludeIp;
    private volatile String notifyPermission;
    private volatile Duration timeout = Duration.ofSeconds(10);
    private volatile boolean active = true;

    WebhookService(NextProxy plugin) {
        this.plugin = plugin;
    }

    void load(YamlConfig config) {
        this.url = config.getString("webhook-url", "").trim();
        username = config.getString("username", "NextStudios");
        avatarUrl = config.getString("avatar-url", "").trim();
        footer = config.getString("footer", "NextStudios");
        notifyInGame = config.getBoolean("notify-in-game", false);
        reportIncludeIp = config.getBoolean("report-include-ip", false);
        notifyPermission = config.getString("notify-permission", "nextproxy.webhooks.receive");
        timeout = Duration.ofSeconds(Math.max(1, config.getInt("timeout-seconds", 10)));
        this.active = config.getBoolean("active", true);
        Map<String, Boolean> newEvents = new LinkedHashMap<>();
        for (String event : List.of("report", "staff-logs", "notes", "maintenance")) {
            newEvents.put(event, config.getBoolean("events." + event, true));
        }
        Map<String, Integer> newColors = new LinkedHashMap<>();
        for (String event : config.getKeys("colors")) {
            Integer color = parseColor(config.getString("colors." + event, ""));
            if (color != null) {
                newColors.put(event, color);
            }
        }
        Map<String, String> newTitles = new LinkedHashMap<>();
        for (String event : config.getKeys("titles")) {
            newTitles.put(event, config.getString("titles." + event, ""));
        }
        events = Map.copyOf(newEvents);
        colors = Map.copyOf(newColors);
        titles = Map.copyOf(newTitles);
    }

    public boolean isConfigured() {
        String url = this.url;
        return DiscordWebhook.isValidUrl(url);
    }

    public boolean isActive() {
        return this.active;
    }

    public void setActive(boolean value) {
        this.active = value;
    }

    public boolean isEnabled(String event) {
        return this.active && isConfigured() && Boolean.TRUE.equals(events.get(event));
    }

    public void report(String reporter, String reported, String reason, String server, String ip) {
        DiscordWebhook.Embed embed = embed("report", "Nuovo report", "Un player è stato segnalato.")
                .addField("Segnalante", clean(reporter), true)
                .addField("Segnalato", clean(reported), true)
                .addField("Motivo", clean(reason), false)
                .addField("Server", clean(server), true);
        if (reportIncludeIp) {
            embed.addField("IP", clean(ip), true);
        }
        send("report", embed);
    }

    public void staffLog(String player, String action, String server) {
        DiscordWebhook.Embed embed = embed("staff-logs", "Staff log", null)
                .addField("Staff", clean(player), true)
                .addField("Azione", clean(action), true)
                .addField("Server", clean(server), true);
        send("staff-logs", embed);
    }

    public void note(String author, String target, String text) {
        DiscordWebhook.Embed embed = embed("notes", "Nuova nota staff", null)
                .addField("Autore", clean(author), true)
                .addField("Player", clean(target), true)
                .addField("Nota", clean(text), false);
        send("notes", embed);
    }

    public void maintenance(String actor, boolean active, int kicked) {
        DiscordWebhook.Embed embed = embed("maintenance", active ? "Manutenzione attivata" : "Manutenzione disattivata", null)
                .addField("Staff", clean(actor), true)
                .addField("Player espulsi", String.valueOf(kicked), true);
        send("maintenance", embed);
    }

    public void test() {
        DiscordWebhook.Embed embed = embed("report", "Test NextStudios", "Se leggi questo messaggio, il webhook funziona.")
                .addField("Modulo", "webhooks", true)
                .addField("Player online", String.valueOf(this.plugin.proxy().getPlayerCount()), true);
        send("report", embed);
    }

    private DiscordWebhook.Embed embed(String event, String defaultTitle, String description) {
        DiscordWebhook.Embed embed = new DiscordWebhook.Embed()
                .title(titles.getOrDefault(event, defaultTitle))
                .color(colors.getOrDefault(event, DEFAULT_COLOR))
                .timestamp(Instant.now());
        if (description != null) {
            embed.description(description);
        }
        if (!footer.isEmpty()) {
            embed.footer(footer);
        }
        return embed;
    }

    private void send(String event, DiscordWebhook.Embed embed) {
        if (!isEnabled(event)) {
            return;
        }
        DiscordWebhook.post(this.url, username, avatarUrl, null, timeout, embed)
                .thenAccept(status -> {
                    if (status < 200 || status > 299) {
                        this.plugin.logger().warn("Webhook Discord '{}' ha risposto {}", event, status);
                        return;
                    }
                    if (notifyInGame && (event.equals("report") || event.equals("notes"))) {
                        notifyStaff(event);
                    }
                })
                .exceptionally(error -> null);
    }

    private void notifyStaff(String event) {
        for (Player player : this.plugin.proxy().getAllPlayers()) {
            if (!notifyPermission.isEmpty() && !player.hasPermission(notifyPermission)) {
                continue;
            }
            this.plugin.moduleMessages("webhooks").send(player, "sent", Text.token("event", event));
        }
    }

    private static String clean(String value) {
        String text = value == null || value.isBlank() ? "-" : value;
        return text.length() > MAX_FIELD ? text.substring(0, MAX_FIELD) : text;
    }

    static Integer parseColor(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String value = raw.trim();
        try {
            if (value.startsWith("#")) {
                return Integer.parseInt(value.substring(1), 16);
            }
            if (value.toLowerCase(Locale.ROOT).startsWith("0x")) {
                return Integer.parseInt(value.substring(2), 16);
            }
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
