package com.nextstudios.proxy.module.stafflogs;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.webhook.WebhookService;
import com.nextstudios.proxy.user.User;

import com.nextstudios.proxy.util.Text;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class StaffLogsModule
extends Module {
    private String trackedPermission;
    private String viewPermission;
    private boolean logJoin;
    private boolean logQuit;
    private boolean logSwitch;
    private boolean logToConsole;

    public StaffLogsModule(NextProxy plugin) {
        super(plugin, "stafflogs");
    }

    @Override
    protected void onEnable() {
        trackedPermission = config().getString("tracked-permission", "NextProxy.stafflogs.tracked");
        viewPermission = config().getString("view-permission", "NextProxy.stafflogs.view");
        logJoin = config().getBoolean("log-join", true);
        logQuit = config().getBoolean("log-quit", true);
        logSwitch = config().getBoolean("log-switch", true);
        logToConsole = config().getBoolean("log-to-console", true);
        listen(this);
        command("toggle", spec -> new ToggleCommand(spec));
    }

    @Subscribe
    public void onServerConnected(ServerConnectedEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission(trackedPermission)) {
            return;
        }
        String to = event.getServer().getServerInfo().getName();
        RegisteredServer previous = event.getPreviousServer().orElse(null);
        if (previous == null) {
            if (logJoin) {
                broadcast(player, "join", "entrata", to, Text.token("player", player.getUsername()), Text.token("server", to));
            }
        } else if (logSwitch) {
            String from = previous.getServerInfo().getName();
            broadcast(player, "switch", "cambio server (" + from + " → " + to + ")", to,
                    Text.token("player", player.getUsername()), Text.token("from", from), Text.token("to", to));
        }
    }

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        Player player = event.getPlayer();
        if (!logQuit || event.getLoginStatus() != DisconnectEvent.LoginStatus.SUCCESSFUL_LOGIN || !player.hasPermission(trackedPermission)) {
            return;
        }
        String server = player.getCurrentServer().map(connection -> connection.getServerInfo().getName()).orElse("-");
        broadcast(player, "quit", "uscita", server, Text.token("player", player.getUsername()), Text.token("server", server));
    }

    private void broadcast(Player subject, String key, String action, String server, TagResolver... resolvers) {
        Component message = messages().get(key, resolvers);
        for (Player viewer : proxy().getAllPlayers()) {
            if (viewer.equals(subject) || !viewer.hasPermission(viewPermission) || !users().get(viewer).staffLogs()) continue;
            viewer.sendMessage(message);
        }
        if (logToConsole) {
            logger().info(Text.plain(message));
        }
        WebhookService hooks = this.plugin.webhooks();
        if (hooks != null) {
            hooks.staffLog(subject.getUsername(), action, server);
        }
    }

    private final class ToggleCommand
    extends BaseCommand {
        ToggleCommand(CommandSpec spec) {
            super(StaffLogsModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            Player player = requirePlayer(source);
            if (player == null) {
                return;
            }
            User user = users().get(player);
            boolean enabled = !user.staffLogs();
            user.staffLogs(enabled);
            users().save(user);
            messages().send(source, enabled ? "toggle-on" : "toggle-off");
        }
    }
}
