package com.nextstudios.proxy.module.broadcast;

import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.module.Module;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class AutoBroadcastModule
extends Module {
    private final List<String> templates = new ArrayList<>();
    private final Set<String> excludedServers = new HashSet<>();
    private boolean random;
    private int minPlayers;
    private int next;

    public AutoBroadcastModule(NextProxy plugin) {
        super(plugin, "autobroadcast");
    }

    @Override
    protected void onEnable() {
        templates.clear();
        for (Object entry : config().getList("broadcasts")) {

            if (entry instanceof List lines) {
                ArrayList<String> parts = new ArrayList<>();
                for (Object line : lines) {
                    parts.add(line == null ? "" : String.valueOf(line));
                }
                templates.add(String.join("\n", parts));
                continue;
            }
            if (entry == null) continue;
            templates.add(String.valueOf(entry));
        }
        excludedServers.clear();
        for (String server : config().getStringList("excluded-servers")) {
            excludedServers.add(server.toLowerCase(Locale.ROOT));
        }
        random = config().getBoolean("random", false);
        minPlayers = Math.max(0, config().getInt("min-players", 1));
        next = random ? -1 : 0;
        long interval = Math.max(5L, config().getLong("interval-seconds", 300L));
        if (templates.isEmpty()) {
            logger().warn("AutoBroadcast attivo ma senza broadcast in modules/autobroadcast.yml");

            return;
        }
        repeat(interval, interval, TimeUnit.SECONDS, this::broadcastNext);
    }

    private synchronized void broadcastNext() {
        int index;
        if (proxy().getPlayerCount() < minPlayers || templates.isEmpty()) {
            return;
        }
        int size = templates.size();
        if (!random || size == 1) {
            index = next % size;
            next = index + 1;
        } else {
            index = ThreadLocalRandom.current().nextInt(next >= 0 ? size - 1 : size);
            if (next >= 0 && index >= next) {
                index++;
            }
            next = index;
        }
        Component message = messages().parse(templates.get(index));
        for (Player player : proxy().getAllPlayers()) {
            boolean excluded = player.getCurrentServer().map(connection -> excludedServers.contains(connection.getServerInfo().getName().toLowerCase(Locale.ROOT))).orElse(false);
            if (excluded) continue;
            player.sendMessage(message);
        }
    }
}
