package com.nextstudios.proxy.module.report;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.webhook.WebhookService;
import com.nextstudios.proxy.util.Names;
import com.nextstudios.proxy.util.Text;

import java.util.List;
import java.util.Optional;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class ReportModule
extends Module {
    private String receivePermission;
    private String bypassCooldownPermission;
    private long cooldownMillis;
    private int minLength;
    private int maxLength;
    private boolean logToConsole;

    public ReportModule(NextProxy plugin) {
        super(plugin, "report");
    }

    @Override
    protected void onEnable() {
        receivePermission = config().getString("receive-permission", "NextProxy.report.receive");
        bypassCooldownPermission = config().getString("bypass-cooldown-permission", "NextProxy.report.bypass");
        cooldownMillis = Math.max(0L, config().getLong("cooldown-seconds", 60L)) * 1000L;
        minLength = Math.max(1, config().getInt("min-reason-length", 3));
        maxLength = Math.max(minLength, config().getInt("max-reason-length", 100));
        logToConsole = config().getBoolean("log-to-console", true);
        command("report", spec -> new ReportCommand(spec));
    }

    private final class ReportCommand
    extends BaseCommand {
        ReportCommand(CommandSpec spec) {
            super(ReportModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            long wait;
            Player reporter = requirePlayer(source);
            if (reporter == null) {
                return;
            }
            if (args.length < 2) {
                messages().usage(source, "usage");
                return;
            }
            Optional<Player> found = users().find(reporter, args[0]);
            if (found.isEmpty()) {
                messages().send(source, "general.player-not-found", Text.token("player", args[0]));
                return;
            }
            Player reported = found.get();
            if (reported.equals(reporter)) {
                messages().send(source, "self");
                return;
            }
            String reason = ReportCommand.join(args, 1);
            if (reason.length() < ReportModule.this.minLength) {
                messages().send(source, "reason-too-short");
                return;
            }
            if (reason.length() > ReportModule.this.maxLength) {
                messages().send(source, "reason-too-long", Text.token("max", ReportModule.this.maxLength));
                return;
            }
            if ((ReportModule.this.bypassCooldownPermission.isEmpty() || !reporter.hasPermission(ReportModule.this.bypassCooldownPermission)) && (wait = users().get(reporter).tryCooldown("report", ReportModule.this.cooldownMillis)) > 0L) {
                messages().send(source, "general.cooldown", Text.literal("time", messages().time().duration(wait)));
                return;
            }
            String server = reported.getCurrentServer().map(connection -> connection.getServerInfo().getName()).orElse("-");
            TextComponent reasonText = Component.text(reason);
            int receivers = 0;
            for (Player staff : ReportModule.this.proxy().getAllPlayers()) {
                if (ReportModule.this.receivePermission.isEmpty() || !staff.hasPermission(ReportModule.this.receivePermission)) continue;
                messages().send(staff, "alert", Text.token("reporter", users().displayName(reporter, staff)), Text.token("reported", users().displayName(reported, staff)), Text.component("reason", reasonText), Text.token("server", server));
                receivers++;
            }
            messages().send(source, "sent");
            if (receivers == 0) {
                messages().send(source, "no-staff");
            }
            WebhookService hooks = this.plugin.webhooks();
            if (hooks != null) {
                hooks.report(reporter.getUsername(), reported.getUsername(), reason, server, Names.ipOf(reporter));
            }
            if (ReportModule.this.logToConsole) {
                ReportModule.this.logger().info("[REPORT] {} ha reportato {} per \"{}\" nel server {}", reporter.getUsername(), reported.getUsername(), reason, server);
            }

        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            return args.length <= 1 ? users().suggest(source, args.length == 0 ? "" : args[0]) : List.of();
        }
    }
}
