package com.nextstudios.proxy.module.pluginhider;

import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.RootCommandNode;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.command.PlayerAvailableCommandsEvent;
import com.velocitypowered.api.event.player.TabCompleteEvent;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.module.Module;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class PluginHiderModule
extends Module {
    private volatile List<Group> groups = List.of();
    private String bypassPermission;

    public PluginHiderModule(NextProxy plugin) {
        super(plugin, "pluginhider");
    }

    @Override
    protected void onEnable() {
        bypassPermission = config().getString("bypass-permission", "NextProxy.pluginhider.bypass");
        groups = loadGroups();
        listen(this);
    }

    private List<Group> loadGroups() {
        YamlConfig section = config().section("groups");
        LinkedHashMap<String, YamlConfig> raw = new LinkedHashMap<>();
        for (String name : section.getKeys("")) {
            raw.put(name.toLowerCase(Locale.ROOT), section.section(name));
        }
        ArrayList<Group> result = new ArrayList<>();
        for (Map.Entry<String, YamlConfig> entry : raw.entrySet()) {
            Mode mode;
            YamlConfig group = entry.getValue();
            try {
                mode = Mode.valueOf(group.getString("mode", "WHITELIST").trim().toUpperCase(Locale.ROOT));
            }
            catch (IllegalArgumentException e) {
                logger().warn("Plugin hider: modalità non valida nel gruppo {}, uso WHITELIST", entry.getKey());
                mode = Mode.WHITELIST;
            }
            HashSet<String> commands = new HashSet<>();
            collect(entry.getKey(), raw, commands, new HashSet<>());
            result.add(new Group(entry.getKey(), group.getString("permission", "").trim(), group.getInt("priority", 0), mode, group.getBoolean("block-namespaced", true), Set.copyOf(commands)));
        }
        result.sort(Comparator.comparingInt(Group::priority).reversed());
        return List.copyOf(result);
    }

    private void collect(String name, Map<String, YamlConfig> raw, Set<String> into, Set<String> visited) {
        if (!visited.add(name)) {
            return;
        }
        YamlConfig group = raw.get(name);
        if (group == null) {
            logger().warn("Plugin hider: il gruppo ereditato '{}' non esiste", name);
            return;
        }
        for (String command : group.getStringList("commands")) {
            into.add(normalize(command));
        }
        for (String parent : group.getStringList("inherits")) {
            collect(parent.toLowerCase(Locale.ROOT), raw, into, visited);
        }
    }

    private static String normalize(String command) {
        String value = command.trim().toLowerCase(Locale.ROOT);
        return value.startsWith("/") ? value.substring(1) : value;
    }

    private boolean bypasses(Player player) {
        return !bypassPermission.isEmpty() && player.hasPermission(bypassPermission);
    }

    private Group groupOf(Player player) {
        for (Group group : groups) {
            if (!group.permission().isEmpty() && !player.hasPermission(group.permission())) continue;
            return group;
        }
        return null;
    }

    public boolean isAllowed(Player player, String rawLabel) {
        if (bypasses(player)) {
            return true;
        }
        Group group = groupOf(player);
        if (group == null) {
            return true;
        }
        String label = normalize(rawLabel);
        int colon = label.indexOf(58);
        if (colon >= 0) {
            if (group.blockNamespaced()) {
                return false;
            }
            label = label.substring(colon + 1);
        }
        boolean listed = group.commands().contains(label);
        return group.mode() == Mode.WHITELIST ? listed : !listed;
    }

    @Subscribe
    public void onAvailableCommands(PlayerAvailableCommandsEvent event) {
        Player player = event.getPlayer();
        if (bypasses(player)) {
            return;
        }
        RootCommandNode<?> root = event.getRootNode();
        ArrayList<String> blocked = new ArrayList<>();
        for (CommandNode<?> child : root.getChildren()) {
            if (isAllowed(player, child.getName())) continue;
            blocked.add(child.getName());
        }
        for (String name : blocked) {
            root.removeChildByName(name);
        }
    }

    @Subscribe(priority=16383)
    public void onCommand(CommandExecuteEvent event) {
        if (!(event.getCommandSource() instanceof Player player) || !event.getResult().isAllowed()) {
            return;
        }
        String command = event.getCommand().strip();
        if (command.startsWith("/")) {
            command = command.substring(1);
        }
        int space = command.indexOf(' ');
        String label = space < 0 ? command : command.substring(0, space);
        if (label.isEmpty() || isAllowed(player, label)) {
            return;
        }
        event.setResult(CommandExecuteEvent.CommandResult.denied());
        messages().send(player, "blocked");
    }

    @Subscribe
    public void onTabComplete(TabCompleteEvent event) {
        String partial = event.getPartialMessage();
        if (!partial.startsWith("/") || partial.indexOf(' ') >= 0) {
            return;
        }
        Player player = event.getPlayer();
        event.getSuggestions().removeIf(suggestion -> !isAllowed(player, suggestion.startsWith("/") ? suggestion.substring(1) : suggestion));
    }

    private enum Mode {
        WHITELIST,
        BLACKLIST;

    }

    private record Group(String name, String permission, int priority, Mode mode, boolean blockNamespaced, Set<String> commands) {
    }
}
