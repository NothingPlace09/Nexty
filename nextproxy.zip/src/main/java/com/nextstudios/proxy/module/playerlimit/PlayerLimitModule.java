package com.nextstudios.proxy.module.playerlimit;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.player.PlayerChooseInitialServerEvent;
import com.velocitypowered.api.event.player.ServerPreConnectEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.util.Text;
import java.util.ArrayList;
import java.util.List;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class PlayerLimitModule
extends Module {
    private static final long RESERVATION_MILLIS = 15000L;
    private final Map<String, Integer> limits = new ConcurrentHashMap<>();
    private final Map<UUID, Reservation> reservations = new ConcurrentHashMap<>();
    private final Object lock = new Object();
    private String bypassPermission;

    public PlayerLimitModule(NextProxy plugin) {
        super(plugin, "playerlimit");
    }

    @Override
    protected void onEnable() {
        bypassPermission = config().getString("bypass-permission", "NextProxy.playerlimit.bypass");
        try {
            limits.clear();
            for (Map.Entry<String, Integer> entry : this.plugin.dataRepository().limits().get(10L, TimeUnit.SECONDS).entrySet()) {
                limits.put(entry.getKey().toLowerCase(Locale.ROOT), entry.getValue());
            }
        }
        catch (Exception e) {
            throw new IllegalStateException("Impossibile leggere i limiti dei server dal database", e);
        }
        listen(this);
        command("playerlimit", spec -> new PlayerLimitCommand(spec));
    }

    private static String key(RegisteredServer server) {
        return server.getServerInfo().getName().toLowerCase(Locale.ROOT);
    }

    private boolean isFull(RegisteredServer server, Player player) {
        Integer limit = limits.get(key(server));
        if (limit == null || !bypassPermission.isEmpty() && player.hasPermission(bypassPermission)) {
            return false;
        }
        return occupied(server, player) >= limit;
    }

    private int occupied(RegisteredServer server, Player player) {
        String key = key(server);
        Set<UUID> ids = new HashSet<>();
        for (Player connected : server.getPlayersConnected()) {
            if (connected.equals(player)) continue;
            ids.add(connected.getUniqueId());
        }
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Reservation> entry : reservations.entrySet()) {
            Reservation reservation = entry.getValue();
            if (reservation.expires() <= now) {
                reservations.remove(entry.getKey(), reservation);
                continue;
            }
            if (reservation.server().equals(key) && !entry.getKey().equals(player.getUniqueId())) {
                ids.add(entry.getKey());
            }
        }
        return ids.size();
    }

    private record Reservation(String server, long expires) {
    }

    @Subscribe
    public void onConnected(ServerConnectedEvent event) {
        reservations.remove(event.getPlayer().getUniqueId());
    }

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        reservations.remove(event.getPlayer().getUniqueId());
    }

    @Subscribe
    public void onChooseInitialServer(PlayerChooseInitialServerEvent event) {
        Player player = event.getPlayer();
        RegisteredServer initial = event.getInitialServer().orElse(null);
        if (initial == null || !isFull(initial, player)) {
            return;
        }
        for (String name : proxy().getConfiguration().getAttemptConnectionOrder()) {
            RegisteredServer candidate = proxy().getServer(name).orElse(null);
            if (candidate == null || candidate.equals(initial) || isFull(candidate, player)) continue;
            event.setInitialServer(candidate);
            return;
        }
    }

    @Subscribe(priority=-16384)
    public void onPreConnect(ServerPreConnectEvent event) {
        if (!event.getResult().isAllowed()) {
            return;
        }
        Player player = event.getPlayer();
        RegisteredServer target = event.getResult().getServer().orElse(null);
        synchronized (lock) {
            if (target == null || !isFull(target, player)) {
                if (target != null && limits.containsKey(key(target))) {
                    reservations.put(player.getUniqueId(), new Reservation(key(target), System.currentTimeMillis() + RESERVATION_MILLIS));
                }
                return;
            }
        }
        event.setResult(ServerPreConnectEvent.ServerResult.denied());
        if (player.getCurrentServer().isEmpty()) {
            player.disconnect(messages().get("no-server"));
        } else {
            messages().send(player, "full", Text.token("server", target.getServerInfo().getName()), Text.token("limit", limits.getOrDefault(key(target), 0)));
        }
    }

    private final class PlayerLimitCommand
    extends BaseCommand {
        PlayerLimitCommand(CommandSpec spec) {
            super(PlayerLimitModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            int limit;
            if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
                list(source);
                return;
            }
            if (args.length != 2) {
                messages().usage(source, "usage");
                return;
            }
            RegisteredServer server = PlayerLimitModule.this.proxy().getServer(args[0]).orElse(null);
            if (server == null) {
                messages().send(source, "general.server-not-found", Text.token("server", args[0]));
                return;
            }
            String name = server.getServerInfo().getName();
            String key = key(server);
            String value = args[1].toLowerCase(Locale.ROOT);
            if (value.equals("off") || value.equals("remove") || value.equals("reset")) {
                if (!PlayerLimitModule.this.limits.containsKey(key)) {
                    messages().send(source, "not-limited", Text.token("server", name));
                    return;
                }
                this.plugin.dataRepository().removeLimit(key).thenRun(() -> {
                    PlayerLimitModule.this.limits.remove(key);
                    messages().send(source, "removed", Text.token("server", name));
                }).exceptionally(error -> fail(source, error));
                return;
            }
            try {
                limit = Integer.parseInt(value);
            }
            catch (NumberFormatException e) {
                limit = -1;
            }
            if (limit < 0 || limit > 100000) {
                messages().send(source, "general.invalid-number", Text.literal("input", args[1]));
                return;
            }
            int max = limit;
            this.plugin.dataRepository().setLimit(key, max).thenRun(() -> {
                PlayerLimitModule.this.limits.put(key, max);
                messages().send(source, "set", Text.token("server", name), Text.token("limit", max));
            }).exceptionally(error -> fail(source, error));
        }

        private void list(CommandSource source) {
            if (PlayerLimitModule.this.limits.isEmpty()) {
                messages().send(source, "list-empty");
                return;
            }
            messages().send(source, "list-header");
            for (Map.Entry<String, Integer> entry : new TreeMap<>(PlayerLimitModule.this.limits).entrySet()) {
                RegisteredServer server = PlayerLimitModule.this.proxy().getServer(entry.getKey()).orElse(null);
                String name = server == null ? entry.getKey() : server.getServerInfo().getName();
                int online = server == null ? 0 : server.getPlayersConnected().size();
                messages().send(source, "list-entry", Text.token("server", name), Text.token("online", online), Text.token("limit", entry.getValue()));
            }
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length <= 1) {
                ArrayList<String> options = new ArrayList<>();
                options.add("list");
                for (RegisteredServer server : PlayerLimitModule.this.proxy().getAllServers()) {
                    options.add(server.getServerInfo().getName());
                }
                return PlayerLimitCommand.filter(options, args.length == 0 ? "" : args[0]);
            }
            if (args.length == 2 && !args[0].equalsIgnoreCase("list")) {
                return PlayerLimitCommand.filter(List.of("off", "10", "20", "50", "100"), args[1]);
            }
            return List.of();
        }
    }
}
