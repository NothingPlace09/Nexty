package com.nextstudios.proxy.storage;

public record PlayerSettings(boolean staffLogs, boolean staffChat) {
    public static final PlayerSettings DEFAULTS = new PlayerSettings(true, false);
}
