package com.nextstudios.proxy.storage;

import com.nextstudios.proxy.storage.Database;
import com.nextstudios.proxy.user.Disguise;
import com.nextstudios.proxy.user.Skin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class DisguiseRepository {
    private final Database db;

    public DisguiseRepository(Database db) {
        this.db = db;
    }

    public Disguise load(Connection connection, UUID uuid) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement("SELECT name, skin_value, skin_signature FROM " + this.db.table("disguises") + " WHERE uuid = ?");){
            Disguise disguise;
            block16: {
                ResultSet rs;
                block14: {
                    Disguise disguise2;
                    block15: {
                        statement.setString(1, uuid.toString());
                        rs = statement.executeQuery();
                        try {
                            if (rs.next()) break block14;
                            disguise2 = null;
                            if (rs == null) break block15;
                        }
                        catch (Throwable throwable) {
                            if (rs != null) {
                                try {
                                    rs.close();
                                }
                                catch (Throwable throwable2) {
                                    throwable.addSuppressed(throwable2);
                                }
                            }
                            throw throwable;
                        }
                        rs.close();
                    }
                    return disguise2;
                }
                String value = rs.getString(2);
                disguise = new Disguise(rs.getString(1), value == null ? null : new Skin(value, rs.getString(3)));
                if (rs == null) break block16;
                rs.close();
            }
            return disguise;
        }
    }

    public CompletableFuture<Void> save(UUID uuid, Disguise disguise, long now) {
        return this.db.update(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("disguises") + " (uuid, name, name_lower, skin_value, skin_signature, created_at) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = ?, name_lower = ?, skin_value = ?, skin_signature = ?, created_at = ?");){
                String value = disguise.skin() == null ? null : disguise.skin().value();
                String signature = disguise.skin() == null ? null : disguise.skin().signature();
                String lower = disguise.name().toLowerCase(Locale.ROOT);
                statement.setString(1, uuid.toString());
                statement.setString(2, disguise.name());
                statement.setString(3, lower);
                statement.setString(4, value);
                statement.setString(5, signature);
                statement.setLong(6, now);
                statement.setString(7, disguise.name());
                statement.setString(8, lower);
                statement.setString(9, value);
                statement.setString(10, signature);
                statement.setLong(11, now);
                statement.executeUpdate();
            }
        });
    }

    public CompletableFuture<Void> delete(UUID uuid) {
        return this.db.update(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("DELETE FROM " + this.db.table("disguises") + " WHERE uuid = ?");){
                statement.setString(1, uuid.toString());
                statement.executeUpdate();
            }
        });
    }

    public CompletableFuture<Boolean> isNameTaken(String name, UUID except, boolean checkRealPlayers) {
        String lower = name.toLowerCase(Locale.ROOT);
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT 1 FROM " + this.db.table("disguises") + " WHERE name_lower = ? AND uuid <> ? LIMIT 1")) {
                statement.setString(1, lower);
                statement.setString(2, except.toString());
                try (ResultSet rs = statement.executeQuery()) {
                    if (rs.next()) {
                        return true;
                    }
                }
            }
            if (!checkRealPlayers) {
                return false;
            }
            try (PreparedStatement statement = connection.prepareStatement("SELECT 1 FROM " + this.db.table("players") + " WHERE name_lower = ? AND uuid <> ? LIMIT 1")) {
                statement.setString(1, lower);
                statement.setString(2, except.toString());
                try (ResultSet rs = statement.executeQuery()) {
                    return rs.next();
                }
            }
        });
    }

    public CompletableFuture<Optional<CachedSkin>> cachedSkin(String owner) {
        return this.db.query(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT skin_value, skin_signature, fetched_at FROM " + this.db.table("skin_cache") + " WHERE name_lower = ?");){
                Optional<CachedSkin> optional;
                block16: {
                    ResultSet rs;
                    block14: {
                        Optional optional2;
                        block15: {
                            statement.setString(1, owner.toLowerCase(Locale.ROOT));
                            rs = statement.executeQuery();
                            try {
                                if (rs.next()) break block14;
                                optional2 = Optional.empty();
                                if (rs == null) break block15;
                            }
                            catch (Throwable throwable) {
                                if (rs != null) {
                                    try {
                                        rs.close();
                                    }
                                    catch (Throwable throwable2) {
                                        throwable.addSuppressed(throwable2);
                                    }
                                }
                                throw throwable;
                            }
                            rs.close();
                        }
                        return optional2;
                    }
                    optional = Optional.of(new CachedSkin(new Skin(rs.getString(1), rs.getString(2)), rs.getLong(3)));
                    if (rs == null) break block16;
                    rs.close();
                }
                return optional;
            }
        });
    }

    public CompletableFuture<Void> cacheSkin(String owner, Skin skin, long now) {
        return this.db.update(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("INSERT INTO " + this.db.table("skin_cache") + " (name_lower, skin_value, skin_signature, fetched_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE skin_value = ?, skin_signature = ?, fetched_at = ?");){
                statement.setString(1, owner.toLowerCase(Locale.ROOT));
                statement.setString(2, skin.value());
                statement.setString(3, skin.signature());
                statement.setLong(4, now);
                statement.setString(5, skin.value());
                statement.setString(6, skin.signature());
                statement.setLong(7, now);
                statement.executeUpdate();
            }
        });
    }

    public record CachedSkin(Skin skin, long fetchedAt) {
    }
}
