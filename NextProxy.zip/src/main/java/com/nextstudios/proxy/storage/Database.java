package com.nextstudios.proxy.storage;

import com.nextstudios.proxy.config.YamlConfig;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.lang.invoke.CallSite;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;
import org.slf4j.Logger;

public final class Database {
    private static final Pattern PREFIX = Pattern.compile("^[a-zA-Z0-9_]{0,16}$");
    private static final int SCHEMA_VERSION = 1;
    private final Logger logger;
    private final Type type;
    private final String prefix;
    private final HikariDataSource dataSource;
    private final ExecutorService executor;

    public Database(Path dataDirectory, YamlConfig config, Logger logger) {
        this.logger = logger;
        YamlConfig db = config.section("database");
        this.type = Database.parseType(db.getString("type", "H2"));
        this.prefix = db.getString("table-prefix", "np_");
        if (!PREFIX.matcher(this.prefix).matches()) {
            throw new IllegalArgumentException("database.table-prefix non valido (solo lettere, numeri e _ , max 16)");
        }
        HikariConfig hikari = new HikariConfig();
        hikari.setPoolName("NextProxy-Pool");
        int poolSize = Math.max(1, db.getInt("pool.maximum-pool-size", 8));
        if (this.type == Type.H2) {
            Path file = dataDirectory.resolve("data").resolve("database").toAbsolutePath();
            hikari.setDriverClassName("org.h2.Driver");
            hikari.setJdbcUrl("jdbc:h2:file:" + String.valueOf(file) + ";MODE=MySQL;DATABASE_TO_LOWER=TRUE;CASE_INSENSITIVE_IDENTIFIERS=TRUE");
            poolSize = Math.min(poolSize, 4);
        } else {
            hikari.setDriverClassName("org.mariadb.jdbc.Driver");
            hikari.setJdbcUrl("jdbc:mariadb://" + db.getString("host", "localhost") + ":" + db.getInt("port", 3306) + "/" + db.getString("database", "NextProxy"));
            hikari.setUsername(db.getString("username", "root"));
            hikari.setPassword(db.getString("password", ""));
            YamlConfig properties = db.section("properties");
            for (String key : properties.getKeys("")) {
                hikari.addDataSourceProperty(key, properties.getString(key, ""));
            }
        }
        hikari.setMaximumPoolSize(poolSize);
        hikari.setMinimumIdle(Math.min(poolSize, Math.max(0, db.getInt("pool.minimum-idle", 2))));
        hikari.setConnectionTimeout(Math.max(1000L, db.getLong("pool.connection-timeout-ms", 5000L)));
        hikari.setIdleTimeout(Math.max(10000L, db.getLong("pool.idle-timeout-ms", 600000L)));
        hikari.setMaxLifetime(Math.max(30000L, db.getLong("pool.max-lifetime-ms", 1800000L)));
        Thread thread = Thread.currentThread();
        ClassLoader previous = thread.getContextClassLoader();
        thread.setContextClassLoader(Database.class.getClassLoader());
        try {
            this.dataSource = new HikariDataSource(hikari);
        }
        finally {
            thread.setContextClassLoader(previous);
        }
        AtomicInteger counter = new AtomicInteger();
        this.executor = Executors.newFixedThreadPool(poolSize, runnable -> {
            Thread worker = new Thread(runnable, "NextProxy-DB-" + counter.incrementAndGet());
            worker.setDaemon(true);
            return worker;
        });
    }

    private static Type parseType(String raw) {
        try {
            return Type.valueOf(raw.trim().toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("database.type non valido: " + raw + " (usa H2, MYSQL o MARIADB)");
        }
    }

    public Type type() {
        return this.type;
    }

    public String table(String name) {
        return this.prefix + name;
    }

    public <T> CompletableFuture<T> query(SqlFunction<T> function) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection connection = this.dataSource.getConnection()) {
                return function.apply(connection);
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, this.executor);
    }

    public CompletableFuture<Void> update(SqlConsumer consumer) {
        return this.query(connection -> {
            consumer.accept(connection);
            return null;
        });
    }

    public void migrate() throws SQLException {
        String text = this.type == Type.H2 ? "VARCHAR(4096)" : "TEXT";
        List<String> tables = List.of(
            "CREATE TABLE IF NOT EXISTS " + this.table("players") + " (uuid CHAR(36) NOT NULL PRIMARY KEY, name VARCHAR(32) NOT NULL, name_lower VARCHAR(32) NOT NULL, first_join BIGINT NOT NULL, last_join BIGINT NOT NULL, last_ip VARCHAR(45) NULL)",
            "CREATE TABLE IF NOT EXISTS " + this.table("ip_history") + " (uuid CHAR(36) NOT NULL, ip VARCHAR(45) NOT NULL, first_seen BIGINT NOT NULL, last_seen BIGINT NOT NULL, logins INT NOT NULL, PRIMARY KEY (uuid, ip))",
            "CREATE TABLE IF NOT EXISTS " + this.table("settings") + " (uuid CHAR(36) NOT NULL PRIMARY KEY, staff_logs BOOLEAN NOT NULL, staff_chat BOOLEAN NOT NULL)",
            "CREATE TABLE IF NOT EXISTS " + this.table("notes") + " (id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, target_uuid CHAR(36) NOT NULL, author_uuid CHAR(36) NULL, author_name VARCHAR(32) NOT NULL, note VARCHAR(512) NOT NULL, created_at BIGINT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS " + this.table("disguises") + " (uuid CHAR(36) NOT NULL PRIMARY KEY, name VARCHAR(16) NOT NULL, name_lower VARCHAR(16) NOT NULL, skin_value " + text + " NULL, skin_signature " + text + " NULL, created_at BIGINT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS " + this.table("skin_cache") + " (name_lower VARCHAR(32) NOT NULL PRIMARY KEY, skin_value " + text + " NOT NULL, skin_signature " + text + " NULL, fetched_at BIGINT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS " + this.table("maintenance_whitelist") + " (name_lower VARCHAR(32) NOT NULL PRIMARY KEY, name VARCHAR(32) NOT NULL, uuid CHAR(36) NULL, added_at BIGINT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS " + this.table("server_limits") + " (server VARCHAR(64) NOT NULL PRIMARY KEY, max_players INT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS " + this.table("kv") + " (k VARCHAR(64) NOT NULL PRIMARY KEY, v VARCHAR(1024) NOT NULL)"
        );
        Map<String, String> indexes = Map.of("players_name", this.table("players") + " (name_lower)", "ip_history_ip", this.table("ip_history") + " (ip)", "notes_target", this.table("notes") + " (target_uuid)", "disguises_name", this.table("disguises") + " (name_lower)");
        try (Connection connection = this.dataSource.getConnection();
             Statement statement = connection.createStatement()) {
            for (String sql : tables) {
                statement.execute(sql);
            }
            for (Map.Entry<String, String> entry : indexes.entrySet()) {
                this.createIndex(statement, this.table(entry.getKey()), entry.getValue());
            }
            boolean auto = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                statement.execute("DELETE FROM " + this.table("kv") + " WHERE k = 'schema_version'");
                statement.execute("INSERT INTO " + this.table("kv") + " (k, v) VALUES ('schema_version', '1')");
                connection.commit();
            } catch (SQLException e) {
                connection.rollback();
                throw e;
            } finally {
                connection.setAutoCommit(auto);
            }
        }
    }

    private void createIndex(Statement statement, String name, String definition) throws SQLException {
        if (this.type == Type.H2) {
            statement.execute("CREATE INDEX IF NOT EXISTS " + name + " ON " + definition);
            return;
        }
        try {
            statement.execute("CREATE INDEX " + name + " ON " + definition);
        } catch (SQLException e) {
            if (e.getErrorCode() != 1061) {
                throw e;
            }
        }
    }

    public void close() {
        this.executor.shutdown();
        try {
            if (!this.executor.awaitTermination(5L, TimeUnit.SECONDS)) {
                this.logger.warn("Alcune operazioni sul database non sono terminate in tempo");
                this.executor.shutdownNow();
            }
        }
        catch (InterruptedException e) {
            this.executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
        this.dataSource.close();
    }

    public static enum Type {
        H2,
        MYSQL,
        MARIADB;

    }

    @FunctionalInterface
    public static interface SqlFunction<T> {
        public T apply(Connection var1) throws SQLException;
    }

    @FunctionalInterface
    public static interface SqlConsumer {
        public void accept(Connection var1) throws SQLException;
    }
}
