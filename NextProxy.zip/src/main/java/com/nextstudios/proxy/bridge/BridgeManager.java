package com.nextstudios.proxy.bridge;

import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.event.player.ServerPostConnectEvent;
import com.velocitypowered.api.event.player.ServerPreConnectEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import com.velocitypowered.api.proxy.messages.ChannelMessageSource;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.velocitypowered.api.util.GameProfile;
import com.nextstudios.common.BridgeSecret;
import com.nextstudios.common.PlayerState;
import com.nextstudios.common.SignedMessage;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.user.Disguise;
import com.nextstudios.proxy.user.Skin;
import com.nextstudios.proxy.user.User;
import com.nextstudios.proxy.util.Text;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.util.ArrayList;
import java.util.Base64;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.audience.Audience;

public final class BridgeManager {
    public static final MinecraftChannelIdentifier CHANNEL = MinecraftChannelIdentifier.create((String)"nextstudios", (String)"bridge");
    private final NextProxy plugin;
    private final SignedMessage signer;
    private final Map<Integer, Registration> handlers = new ConcurrentHashMap<Integer, Registration>();
    private final Map<String, Long> bridgedServers = new ConcurrentHashMap<String, Long>();
    private volatile long lastWarning;

    public BridgeManager(NextProxy plugin) throws IOException {
        this.plugin = plugin;
        this.signer = new SignedMessage(this.loadSecret(plugin.dataDirectory().resolve("bridge.secret")));
    }

    private byte[] loadSecret(Path file) throws IOException {
        if (Files.exists(file, new LinkOption[0])) {
            try {
                return BridgeSecret.decode(Files.readString(file, StandardCharsets.UTF_8));
            }
            catch (IllegalArgumentException e) {
                throw new IOException("Il file bridge.secret non \u00e8 valido (" + e.getMessage() + "): cancellalo per generarne uno nuovo");
            }
        }
        byte[] secret = BridgeSecret.generate();
        Files.createDirectories(file.getParent(), new FileAttribute[0]);
        Files.writeString(file, (CharSequence)BridgeSecret.encode(secret), StandardCharsets.UTF_8, new OpenOption[0]);
        try {
            Files.setPosixFilePermissions(file, EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
        }
        catch (IOException | UnsupportedOperationException exception) {

        }
        this.plugin.logger().warn("Generato il segreto per NextBridge in {}: copialo nella voce 'secret' del config.yml di NextBridge su OGNI server backend.", (Object)file.toAbsolutePath());
        return secret;
    }

    public void start() {
        this.plugin.proxy().getChannelRegistrar().register(new ChannelIdentifier[]{CHANNEL});
        this.plugin.proxy().getEventManager().register((Object)this.plugin, (Object)this);
    }

    public void stop() {
        this.plugin.proxy().getEventManager().unregisterListener((Object)this.plugin, (Object)this);
        this.plugin.proxy().getChannelRegistrar().unregister(new ChannelIdentifier[]{CHANNEL});
    }

    public void registerHandler(Object owner, int type, Handler handler) {
        this.handlers.put(type, new Registration(owner, handler));
    }

    public void unregisterHandlers(Object owner) {
        this.handlers.values().removeIf(registration -> registration.owner() == owner);
    }

    public boolean isBridged(RegisteredServer server) {
        return this.bridgedServers.containsKey(server.getServerInfo().getName().toLowerCase(Locale.ROOT));
    }

    public Set<String> bridgedServerNames() {
        return new TreeSet<String>(this.bridgedServers.keySet());
    }

    public void warnIfMissing(Player player, String messageKey) {
        if (!this.plugin.config().getBoolean("bridge.warn-missing", true)) {
            return;
        }
        player.getCurrentServer().ifPresent(connection -> {
            if (!this.isBridged(connection.getServer())) {
                this.plugin.messages().send((Audience)player, messageKey, Text.token("server", connection.getServerInfo().getName()));
            }
        });
    }

    public PlayerState stateOf(Player player) {
        Disguise disguise;
        User user = this.plugin.users().get(player);
        int flags = 0;
        if (this.plugin.isModuleEnabled("staffchat") && user.staffChat()) {
            flags |= 1;
        }
        Disguise disguise2 = disguise = this.plugin.isModuleEnabled("disguise") ? user.disguise() : null;
        if (disguise == null) {
            return new PlayerState(player.getUniqueId(), flags, null, null, null);
        }
        Skin skin = disguise.skin();
        return new PlayerState(player.getUniqueId(), flags, disguise.name(), skin == null ? null : skin.value(), skin == null ? null : skin.signature());
    }

    public void push(Player player) {
        player.getCurrentServer().ifPresent(connection -> {
            PlayerState state = this.stateOf(player);
            this.send((ServerConnection)connection, 1, state::write);
        });
    }

    private void send(ServerConnection connection, int type, SignedMessage.Body body) {
        try {
            connection.sendPluginMessage((ChannelIdentifier)CHANNEL, this.signer.seal(type, body));
        }
        catch (IOException e) {
            this.plugin.logger().error("Impossibile inviare un messaggio a NextBridge", (Throwable)e);
        }
    }

    @Subscribe(priority=-32767)
    public void onPreConnect(ServerPreConnectEvent event) {
        if (!event.getResult().isAllowed()) {
            return;
        }
        Player player = event.getPlayer();
        ArrayList<GameProfile.Property> properties = new ArrayList<GameProfile.Property>();
        for (GameProfile.Property property : player.getGameProfileProperties()) {
            if ("nextstudios_state".equals(property.getName())) continue;
            properties.add(property);
        }
        try {
            PlayerState state = this.stateOf(player);
            byte[] sealed = this.signer.seal(1, state::write);
            properties.add(new GameProfile.Property("nextstudios_state", Base64.getEncoder().encodeToString(sealed), ""));
        }
        catch (IOException e) {
            this.plugin.logger().error("Impossibile preparare lo stato di {} per il bridge", (Object)player.getUsername(), (Object)e);
        }
        player.setGameProfileProperties(properties);
    }

    @Subscribe
    public void onPostConnect(ServerPostConnectEvent event) {
        this.push(event.getPlayer());
    }

    @Subscribe(priority=32766)
    public void onPluginMessage(PluginMessageEvent event) {
        SignedMessage.Opened message;
        if (!CHANNEL.equals((Object)event.getIdentifier())) {
            return;
        }
        event.setResult(PluginMessageEvent.ForwardResult.handled());
        ChannelMessageSource channelMessageSource = event.getSource();
        if (!(channelMessageSource instanceof ServerConnection)) {
            ChannelMessageSource channelMessageSource2 = event.getSource();
            if (channelMessageSource2 instanceof Player) {
                Player player = (Player)channelMessageSource2;
                this.warnRateLimited("Scartato un messaggio sul canale del bridge inviato dal client di " + player.getUsername());
            }
            return;
        }
        ServerConnection connection = (ServerConnection)channelMessageSource;
        try {
            message = this.signer.open(event.getData());
        }
        catch (SignedMessage.InvalidMessageException e) {
            this.warnRateLimited("Messaggio del bridge rifiutato dal server " + connection.getServerInfo().getName() + ": " + e.getMessage());
            return;
        }
        this.bridgedServers.put(connection.getServerInfo().getName().toLowerCase(Locale.ROOT), System.currentTimeMillis());
        if (message.type() == 64) {
            return;
        }
        if (message.type() == 69) {
            this.push(connection.getPlayer());
            return;
        }
        Registration registration = this.handlers.get(message.type());
        if (registration == null) {
            return;
        }
        try {
            registration.handler().handle(connection.getPlayer(), message.in());
        }
        catch (IOException | RuntimeException e) {
            this.plugin.logger().warn("Messaggio del bridge non valido (tipo {}) da {}", new Object[]{message.type(), connection.getServerInfo().getName(), e});
        }
    }

    private void warnRateLimited(String text) {
        long now = System.currentTimeMillis();
        if (now - this.lastWarning > 10000L) {
            this.lastWarning = now;
            this.plugin.logger().warn(text);
        }
    }

    private record Registration(Object owner, Handler handler) {
    }

    @FunctionalInterface
    public static interface Handler {
        public void handle(Player var1, DataInputStream var2) throws IOException;
    }
}
