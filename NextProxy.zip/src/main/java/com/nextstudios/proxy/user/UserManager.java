package com.nextstudios.proxy.user;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.EventTask;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.storage.PlayerSettings;
import com.nextstudios.proxy.util.Names;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public final class UserManager {
    private final NextProxy plugin;
    private final Map<UUID, User> users = new ConcurrentHashMap<>();
    private final Map<String, UUID> disguiseIndex = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> cooldownStore = new ConcurrentHashMap<>();
    private volatile String seeRealPermission;

    public UserManager(NextProxy plugin) {
        this.plugin = plugin;
        this.reload();
    }

    public void reload() {
        this.seeRealPermission = this.plugin.moduleConfig("disguise").getString("see-real-permission", "nextproxy.disguise.see");
    }

    public User get(Player player) {
        User existing = this.users.get(player.getUniqueId());
        if (existing != null) {
            return existing;
        }
        if (!player.isActive()) {
            return new User(player);
        }
        return this.users.computeIfAbsent(player.getUniqueId(), id -> new User(player, this.cooldownsOf(id)));
    }

    private Map<String, Long> cooldownsOf(UUID id) {
        return this.cooldownStore.computeIfAbsent(id, key -> new ConcurrentHashMap<>());
    }

    public Optional<User> find(UUID uuid) {
        return Optional.ofNullable(this.users.get(uuid));
    }

    public Collection<User> all() {
        return this.users.values();
    }

    @Subscribe
    public EventTask onLogin(LoginEvent event) {
        if (!event.getResult().isAllowed()) {
            return null;
        }
        Player player = event.getPlayer();
        User user = new User(player, this.cooldownsOf(player.getUniqueId()));
        this.users.put(player.getUniqueId(), user);
        String ip = Names.ipOf(player);
        boolean recordIp = this.plugin.isModuleEnabled("ip") && this.plugin.moduleConfig("ip").getBoolean("record-history", true);
        boolean loadDisguise = this.plugin.isModuleEnabled("disguise") && this.plugin.moduleConfig("disguise").getBoolean("persist", true);
        CompletableFuture<LoadedData> load = this.plugin.database().query(connection -> {
            this.plugin.playerRepository().recordLogin(connection, user.uuid(), user.name(), ip, System.currentTimeMillis(), recordIp);
            PlayerSettings settings = this.plugin.playerRepository().loadSettings(connection, user.uuid());
            Disguise disguise = loadDisguise ? this.plugin.disguiseRepository().load(connection, user.uuid()) : null;
            return new LoadedData(settings, disguise);
        }).thenApply(data -> {
            user.apply(data.settings());
            if (data.disguise() != null) {
                if (!this.setDisguise(user, data.disguise())) {
                    this.plugin.logger().warn("Il disguise '{}' di {} è già in uso da un altro player: resta senza disguise per questa sessione", data.disguise().name(), user.name());
                }
            }
            return data;
        }).exceptionally(error -> {
            this.plugin.logger().error("Impossibile caricare i dati di {} dal database: uso i valori di default", user.name(), error);
            return null;
        });
        return EventTask.resumeWhenComplete(load);
    }

    @Subscribe(priority = -32767)
    public void onDisconnect(DisconnectEvent event) {
        Player player = event.getPlayer();
        this.users.computeIfPresent(player.getUniqueId(), (id, user) -> {
            if (user.player() != player) {
                return user;
            }
            Disguise disguise = user.disguise();
            if (disguise != null) {
                this.disguiseIndex.remove(UserManager.lower(disguise.name()), id);
            }
            return null;
        });
        long now = System.currentTimeMillis();
        this.cooldownStore.computeIfPresent(player.getUniqueId(), (id, map) -> {
            map.values().removeIf(until -> until <= now);
            return map.isEmpty() ? null : map;
        });
    }

    public void save(User user) {
        this.plugin.playerRepository().saveSettings(user.uuid(), user.settings()).exceptionally(error -> {
            this.plugin.logger().error("Impossibile salvare le impostazioni di {}", user.name(), error);
            return null;
        });
    }

    public boolean setDisguise(User user, Disguise disguise) {
        UUID id = user.uuid();
        if (this.users.get(id) != user) {
            return false;
        }
        if (disguise != null) {
            UUID holder = this.disguiseIndex.putIfAbsent(UserManager.lower(disguise.name()), id);
            if (holder != null && !holder.equals(id)) {
                return false;
            }
        }
        Disguise old = user.disguise();
        if (old != null && (disguise == null || !UserManager.lower(old.name()).equals(UserManager.lower(disguise.name())))) {
            this.disguiseIndex.remove(UserManager.lower(old.name()), id);
        }
        user.disguise(disguise);
        return true;
    }

    public Optional<Player> byDisguiseName(String name) {
        UUID uuid = this.disguiseIndex.get(UserManager.lower(name));
        return uuid == null ? Optional.empty() : this.plugin.proxy().getPlayer(uuid);
    }

    public boolean isDisguiseNameInUse(String name) {
        return this.disguiseIndex.containsKey(UserManager.lower(name));
    }

    public boolean isDisguised(Player player) {
        return this.plugin.isModuleEnabled("disguise") && this.get(player).disguise() != null;
    }

    public boolean canSeeReal(CommandSource viewer) {
        return !(viewer instanceof Player) || ((Player)viewer).hasPermission(this.seeRealPermission);
    }

    public String displayName(Player target, CommandSource viewer) {
        if (!target.equals(viewer) && this.isDisguised(target) && !this.canSeeReal(viewer)) {
            return this.get(target).disguise().name();
        }
        return target.getUsername();
    }

    public Optional<Player> find(CommandSource viewer, String input) {
        return this.find(viewer, input, true);
    }

    public Optional<Player> find(CommandSource viewer, String input, boolean allowDisguiseNames) {
        if (input == null || input.isEmpty() || input.length() > 32) {
            return Optional.empty();
        }
        Player result = null;
        boolean disguiseActive = this.plugin.isModuleEnabled("disguise");
        if (disguiseActive && (allowDisguiseNames || this.canSeeReal(viewer))) {
            result = this.byDisguiseName(input).orElse(null);
        }
        if (result == null) {
            Player byName = this.plugin.proxy().getPlayer(input).orElse(null);
            if (byName != null && disguiseActive && this.get(byName).disguise() != null && !byName.equals(viewer) && !this.canSeeReal(viewer)) {
                byName = null;
            }
            result = byName;
        }
        return Optional.ofNullable(result);
    }

    public List<String> suggest(CommandSource viewer, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        ArrayList<String> result = new ArrayList<>();
        for (Player player : this.plugin.proxy().getAllPlayers()) {
            String name = this.displayName(player, viewer);
            if (!name.toLowerCase(Locale.ROOT).startsWith(lower)) {
                continue;
            }
            result.add(name);
        }
        result.sort(String.CASE_INSENSITIVE_ORDER);
        return result;
    }

    private static String lower(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    private record LoadedData(PlayerSettings settings, Disguise disguise) {
    }
}
