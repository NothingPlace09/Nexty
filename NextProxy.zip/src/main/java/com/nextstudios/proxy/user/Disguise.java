package com.nextstudios.proxy.user;

import com.nextstudios.proxy.user.Skin;

public record Disguise(String name, Skin skin) {
}
