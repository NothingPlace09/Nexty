package com.nextstudios.proxy;

import com.velocitypowered.api.command.CommandSource;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.config.Messages;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.util.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

final class CoreCommand
extends BaseCommand {
    CoreCommand(NextProxy plugin, CommandSpec spec, Messages messages) {
        super(plugin, spec, messages);
    }

    @Override
    protected void execute(CommandSource source, String[] args) {
        String sub;
        switch (sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT)) {
            case "reload": {
                long start = System.currentTimeMillis();
                if (this.plugin.reload()) {
                    this.messages().send((Audience)source, "reloaded", Text.token("time", System.currentTimeMillis() - start));
                    break;
                }
                this.messages().send((Audience)source, "reload-failed", new TagResolver[0]);
                break;
            }
            case "info": {
                ArrayList<String> enabled = new ArrayList<String>();
                for (Module module : this.plugin.modules()) {
                    if (!module.isEnabled()) continue;
                    enabled.add(module.id());
                }
                Set<String> bridged = this.plugin.bridge().bridgedServerNames();
                this.messages().send((Audience)source, "info", Text.token("version", NextProxy.VERSION), Text.token("database", this.plugin.database().type().name()), Text.literal("modules", enabled.isEmpty() ? "-" : String.join((CharSequence)", ", enabled)), Text.literal("bridged", bridged.isEmpty() ? "-" : String.join((CharSequence)", ", bridged)));
                break;
            }
            default: {
                this.messages().send((Audience)source, "help", Text.token("version", NextProxy.VERSION));
            }
        }
    }

    @Override
    protected List<String> suggest(CommandSource source, String[] args) {
        return args.length <= 1 ? CoreCommand.filter(List.of("reload", "info", "help"), args.length == 0 ? "" : args[0]) : List.of();
    }
}
