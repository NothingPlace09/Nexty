package com.nextstudios.proxy.util;

import com.nextstudios.common.LegacyText;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.ComponentLike;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

public final class Text {
    private static final MiniMessage MINI = MiniMessage.miniMessage();
    private static final LegacyComponentSerializer AMPERSAND = LegacyComponentSerializer.legacyAmpersand();
    private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.legacySection();
    private static final Pattern SAFE_TOKEN = Pattern.compile("^[\\w.:\\-*#]{0,64}$");

    private Text() {
    }

    public static String legacyToMini(String input) {
        return LegacyText.toMiniMessage(input);
    }

    public static Component parse(String template, TagResolver ... resolvers) {
        return MINI.deserialize(Text.legacyToMini(template), resolvers);
    }

    public static TagResolver token(String key, Object value) {
        String text = String.valueOf(value);
        return SAFE_TOKEN.matcher(text).matches() ? Placeholder.parsed((String)key, (String)text) : Placeholder.unparsed((String)key, (String)text);
    }

    public static TagResolver literal(String key, String value) {
        return Placeholder.unparsed((String)key, (String)(value == null ? "" : value));
    }

    public static TagResolver component(String key, Component value) {
        return Placeholder.component((String)key, (ComponentLike)value);
    }

    public static Component userText(String text, boolean colors) {
        return colors ? AMPERSAND.deserialize(text) : Component.text((String)text);
    }

    public static String plain(Component component) {
        return PlainTextComponentSerializer.plainText().serialize(component);
    }

    public static String legacySection(Component component) {
        return SECTION.serialize(component);
    }
}
