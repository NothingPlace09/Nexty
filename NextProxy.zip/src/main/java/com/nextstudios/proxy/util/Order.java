package com.nextstudios.proxy.util;

public final class Order {
    public static final short FIRST = 32766;
    public static final short EARLY = 16383;
    public static final short LATE = -16384;
    public static final short LAST = -32767;

    private Order() {
    }
}
