package com.nextstudios.proxy.config;

import java.io.IOException;
import java.nio.file.Path;

public final class ModuleConfig {
    private final String id;
    private final YamlConfig settings;
    private final Messages messages;

    private ModuleConfig(String id, YamlConfig settings, Messages messages) {
        this.id = id;
        this.settings = settings;
        this.messages = messages;
    }

    public static ModuleConfig load(Path modulesDirectory, String id, YamlConfig config, Messages global) throws IOException {
        YamlConfig file = YamlConfig.loadOptional(modulesDirectory.resolve(id + ".yml"), "modules/" + id + ".yml");
        return new ModuleConfig(id, file, Messages.module(file, config, global));
    }

    public static ModuleConfig empty(String id, YamlConfig config, Messages global) {
        YamlConfig file = YamlConfig.empty();
        return new ModuleConfig(id, file, Messages.module(file, config, global));
    }

    public static ModuleConfig disabled(String id, YamlConfig config, Messages global) {
        YamlConfig file = YamlConfig.of(java.util.Map.of("enabled", Boolean.FALSE));
        return new ModuleConfig(id, file, Messages.module(file, config, global));
    }

    public String id() {
        return this.id;
    }

    public YamlConfig settings() {
        return this.settings;
    }

    public Messages messages() {
        return this.messages;
    }
}
