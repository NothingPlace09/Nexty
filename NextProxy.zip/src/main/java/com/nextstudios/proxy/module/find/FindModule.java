package com.nextstudios.proxy.module.find;

import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.util.Text;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import java.util.List;
import java.util.Optional;
import net.kyori.adventure.audience.Audience;

public final class FindModule
extends Module {
    public FindModule(NextProxy plugin) {
        super(plugin, "find");
    }

    @Override
    protected void onEnable() {
        this.command("find", spec -> new FindCommand(spec));
    }

    private final class FindCommand
    extends BaseCommand {
        FindCommand(CommandSpec spec) {
            super(FindModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (args.length != 1) {
                this.messages().usage((Audience)source, "usage");
                return;
            }
            String input = args[0];
            Optional<Player> found = this.users().find(source, input);
            if (found.isEmpty()) {
                this.messages().send((Audience)source, "general.player-not-found", Text.literal("player", input));
                return;
            }
            Player target = found.get();
            String name = this.users().displayName(target, source);
            String server = target.getCurrentServer()
                    .map(ServerConnection::getServerInfo)
                    .map(info -> info.getName())
                    .orElse(null);
            if (server == null) {
                this.messages().send((Audience)source, "connecting", Text.literal("player", name));
                return;
            }
            this.messages().send((Audience)source, "found", Text.literal("player", name), Text.literal("server", server));
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length > 1) {
                return List.of();
            }
            return this.users().suggest(source, args.length == 0 ? "" : args[0]);
        }
    }
}
