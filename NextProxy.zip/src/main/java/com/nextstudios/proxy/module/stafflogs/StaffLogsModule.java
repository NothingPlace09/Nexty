package com.nextstudios.proxy.module.stafflogs;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.webhook.WebhookService;
import com.nextstudios.proxy.user.User;

import com.nextstudios.proxy.util.Text;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class StaffLogsModule
extends Module {
    private String trackedPermission;
    private String viewPermission;
    private boolean logJoin;
    private boolean logQuit;
    private boolean logSwitch;
    private boolean logToConsole;

    public StaffLogsModule(NextProxy plugin) {
        super(plugin, "stafflogs");
    }

    @Override
    protected void onEnable() {
        this.trackedPermission = this.config().getString("tracked-permission", "NextProxy.stafflogs.tracked");
        this.viewPermission = this.config().getString("view-permission", "NextProxy.stafflogs.view");
        this.logJoin = this.config().getBoolean("log-join", true);
        this.logQuit = this.config().getBoolean("log-quit", true);
        this.logSwitch = this.config().getBoolean("log-switch", true);
        this.logToConsole = this.config().getBoolean("log-to-console", true);
        this.listen(this);
        this.command("toggle", spec -> new ToggleCommand((CommandSpec)spec));
    }

    @Subscribe
    public void onServerConnected(ServerConnectedEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission(this.trackedPermission)) {
            return;
        }
        String to = event.getServer().getServerInfo().getName();
        RegisteredServer previous = event.getPreviousServer().orElse(null);
        if (previous == null) {
            if (this.logJoin) {
                this.broadcast(player, "join", "entrata", to, Text.token("player", player.getUsername()), Text.token("server", to));
            }
        } else if (this.logSwitch) {
            String from = previous.getServerInfo().getName();
            this.broadcast(player, "switch", "cambio server (" + from + " → " + to + ")", to,
                    Text.token("player", player.getUsername()), Text.token("from", from), Text.token("to", to));
        }
    }

    @Subscribe
    public void onDisconnect(DisconnectEvent event) {
        Player player = event.getPlayer();
        if (!this.logQuit || event.getLoginStatus() != DisconnectEvent.LoginStatus.SUCCESSFUL_LOGIN || !player.hasPermission(this.trackedPermission)) {
            return;
        }
        String server = player.getCurrentServer().map(connection -> connection.getServerInfo().getName()).orElse("-");
        this.broadcast(player, "quit", "uscita", server, Text.token("player", player.getUsername()), Text.token("server", server));
    }

    private void broadcast(Player subject, String key, String action, String server, TagResolver... resolvers) {
        Component message = this.messages().get(key, resolvers);
        for (Player viewer : this.proxy().getAllPlayers()) {
            if (viewer.equals((Object)subject) || !viewer.hasPermission(this.viewPermission) || !this.users().get(viewer).staffLogs()) continue;
            viewer.sendMessage(message);
        }
        if (this.logToConsole) {
            this.logger().info(Text.plain(message));
        }
        WebhookService hooks = this.plugin.webhooks();
        if (hooks != null) {
            hooks.staffLog(subject.getUsername(), action, server);
        }
    }

    private final class ToggleCommand
    extends BaseCommand {
        ToggleCommand(CommandSpec spec) {
            super(StaffLogsModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            Player player = this.requirePlayer(source);
            if (player == null) {
                return;
            }
            User user = this.users().get(player);
            boolean enabled = !user.staffLogs();
            user.staffLogs(enabled);
            this.users().save(user);
            this.messages().send((Audience)source, enabled ? "toggle-on" : "toggle-off", new TagResolver[0]);
        }
    }
}
