package com.nextstudios.proxy.module.disguise;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.storage.DisguiseRepository;
import com.nextstudios.proxy.user.Skin;
import java.io.IOException;
import java.lang.invoke.CallSite;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

final class SkinService {
    private static final Pattern NAME = Pattern.compile("^[A-Za-z0-9_]{1,16}$");
    private static final Pattern UNDASHED_UUID = Pattern.compile("^[0-9a-fA-F]{32}$");
    private final NextProxy plugin;
    private final List<Skin> skins = new CopyOnWriteArrayList<Skin>();
    private final ExecutorService executor;
    private final HttpClient http;
    private volatile boolean closed;

    SkinService(NextProxy plugin) {
        this.plugin = plugin;
        this.executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "NextProxy-Skins");
            thread.setDaemon(true);
            return thread;
        });
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).followRedirects(HttpClient.Redirect.NORMAL).build();
    }

    void load(List<String> owners, List<Skin> fixed, long cacheHours) {
        this.skins.addAll(fixed);
        long maxAge = Math.max(1L, cacheHours) * 3600000L;
        this.executor.execute(() -> {
            for (String owner : owners) {
                if (this.closed) {
                    return;
                }
                if (!NAME.matcher(owner).matches()) {
                    this.plugin.logger().warn("Disguise: '{}' non \u00e8 un nick valido per le skin", (Object)owner);
                    continue;
                }
                try {
                    Optional<DisguiseRepository.CachedSkin> cached = this.plugin.disguiseRepository().cachedSkin(owner).get(10L, TimeUnit.SECONDS);
                    if (cached.isPresent() && System.currentTimeMillis() - cached.get().fetchedAt() < maxAge) {
                        this.skins.add(cached.get().skin());
                        continue;
                    }
                    Optional<Skin> fetched = this.fetch(owner);
                    if (fetched.isPresent()) {
                        this.skins.add(fetched.get());
                        this.plugin.disguiseRepository().cacheSkin(owner, fetched.get(), System.currentTimeMillis()).get(10L, TimeUnit.SECONDS);
                        continue;
                    }
                    if (cached.isPresent()) {
                        this.skins.add(cached.get().skin());
                        continue;
                    }
                    this.plugin.logger().warn("Disguise: skin di '{}' non trovata", (Object)owner);
                }
                catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
                catch (Exception e) {
                    this.plugin.logger().warn("Disguise: impossibile scaricare la skin di '{}': {}", (Object)owner, (Object)e.getMessage());
                }
            }
            if (!this.closed) {
                this.plugin.logger().info("Disguise: {} skin disponibili", (Object)this.skins.size());
            }
        });
    }

    Optional<Skin> random() {
        List<Skin> snapshot = List.copyOf(this.skins);
        return snapshot.isEmpty() ? Optional.empty() : Optional.of(snapshot.get(ThreadLocalRandom.current().nextInt(snapshot.size())));
    }

    void close() {
        this.closed = true;
        this.executor.shutdownNow();
    }

    private Optional<Skin> fetch(String owner) throws IOException, InterruptedException {
        String uuid = this.lookupUuid(owner);
        if (uuid == null) {
            return Optional.empty();
        }
        HttpResponse<String> response = this.get("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid + "?unsigned=false");
        if (response.statusCode() != 200) {
            return Optional.empty();
        }
        JsonArray properties = JsonParser.parseString((String)response.body()).getAsJsonObject().getAsJsonArray("properties");
        if (properties == null) {
            return Optional.empty();
        }
        for (JsonElement element : properties) {
            JsonObject property = element.getAsJsonObject();
            if (!"textures".equals(property.get("name").getAsString())) continue;
            String signature = property.has("signature") ? property.get("signature").getAsString() : null;
            return Optional.of(new Skin(property.get("value").getAsString(), signature));
        }
        return Optional.empty();
    }

    private String lookupUuid(String owner) throws IOException, InterruptedException {
        List<String> endpoints = List.of("https://api.minecraftservices.com/minecraft/profile/lookup/name/" + owner, "https://api.mojang.com/users/profiles/minecraft/" + owner);
        for (String string : endpoints) {
            HttpResponse<String> response = this.get(string);
            if (response.statusCode() == 200) {
                JsonObject json = JsonParser.parseString((String)response.body()).getAsJsonObject();
                String id = json.has("id") ? json.get("id").getAsString() : "";
                return UNDASHED_UUID.matcher(id).matches() ? id : null;
            }
            if (response.statusCode() != 204 && response.statusCode() != 404) continue;
            return null;
        }
        return null;
    }

    private HttpResponse<String> get(String url) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(8L)).header("User-Agent", "NextProxy/1.0.0").GET().build();
        return this.http.send(request, HttpResponse.BodyHandlers.ofString());
    }
}
