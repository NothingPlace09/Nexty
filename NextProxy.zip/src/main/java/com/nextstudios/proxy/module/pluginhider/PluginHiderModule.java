package com.nextstudios.proxy.module.pluginhider;

import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.RootCommandNode;
import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.command.PlayerAvailableCommandsEvent;
import com.velocitypowered.api.event.player.TabCompleteEvent;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.config.YamlConfig;
import com.nextstudios.proxy.module.Module;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class PluginHiderModule
extends Module {
    private volatile List<Group> groups = List.of();
    private String bypassPermission;

    public PluginHiderModule(NextProxy plugin) {
        super(plugin, "pluginhider");
    }

    @Override
    protected void onEnable() {
        this.bypassPermission = this.config().getString("bypass-permission", "NextProxy.pluginhider.bypass");
        this.groups = this.loadGroups();
        this.listen(this);
    }

    private List<Group> loadGroups() {
        YamlConfig section = this.config().section("groups");
        LinkedHashMap<String, YamlConfig> raw = new LinkedHashMap<String, YamlConfig>();
        for (String name : section.getKeys("")) {
            raw.put(name.toLowerCase(Locale.ROOT), section.section(name));
        }
        ArrayList<Group> result = new ArrayList<Group>();
        for (Map.Entry entry : raw.entrySet()) {
            Mode mode;
            YamlConfig group = (YamlConfig)entry.getValue();
            try {
                mode = Mode.valueOf(group.getString("mode", "WHITELIST").trim().toUpperCase(Locale.ROOT));
            }
            catch (IllegalArgumentException e) {
                this.logger().warn("Plugin hider: modalit\u00e0 non valida nel gruppo {}, uso WHITELIST", entry.getKey());
                mode = Mode.WHITELIST;
            }
            HashSet<String> commands = new HashSet<String>();
            this.collect((String)entry.getKey(), raw, commands, new HashSet<String>());
            result.add(new Group((String)entry.getKey(), group.getString("permission", "").trim(), group.getInt("priority", 0), mode, group.getBoolean("block-namespaced", true), Set.copyOf(commands)));
        }
        result.sort(Comparator.comparingInt(Group::priority).reversed());
        return List.copyOf(result);
    }

    private void collect(String name, Map<String, YamlConfig> raw, Set<String> into, Set<String> visited) {
        if (!visited.add(name)) {
            return;
        }
        YamlConfig group = raw.get(name);
        if (group == null) {
            this.logger().warn("Plugin hider: il gruppo ereditato '{}' non esiste", (Object)name);
            return;
        }
        for (String command : group.getStringList("commands")) {
            into.add(PluginHiderModule.normalize(command));
        }
        for (String parent : group.getStringList("inherits")) {
            this.collect(parent.toLowerCase(Locale.ROOT), raw, into, visited);
        }
    }

    private static String normalize(String command) {
        String value = command.trim().toLowerCase(Locale.ROOT);
        return value.startsWith("/") ? value.substring(1) : value;
    }

    private boolean bypasses(Player player) {
        return !this.bypassPermission.isEmpty() && player.hasPermission(this.bypassPermission);
    }

    private Group groupOf(Player player) {
        for (Group group : this.groups) {
            if (!group.permission().isEmpty() && !player.hasPermission(group.permission())) continue;
            return group;
        }
        return null;
    }

    public boolean isAllowed(Player player, String rawLabel) {
        if (this.bypasses(player)) {
            return true;
        }
        Group group = this.groupOf(player);
        if (group == null) {
            return true;
        }
        String label = PluginHiderModule.normalize(rawLabel);
        int colon = label.indexOf(58);
        if (colon >= 0) {
            if (group.blockNamespaced()) {
                return false;
            }
            label = label.substring(colon + 1);
        }
        boolean listed = group.commands().contains(label);
        return group.mode() == Mode.WHITELIST ? listed : !listed;
    }

    @Subscribe
    public void onAvailableCommands(PlayerAvailableCommandsEvent event) {
        Player player = event.getPlayer();
        if (this.bypasses(player)) {
            return;
        }
        RootCommandNode<?> root = event.getRootNode();
        ArrayList<String> blocked = new ArrayList<String>();
        for (CommandNode<?> child : root.getChildren()) {
            if (this.isAllowed(player, child.getName())) continue;
            blocked.add(child.getName());
        }
        for (String name : blocked) {
            root.removeChildByName(name);
        }
    }

    @Subscribe(priority=16383)
    public void onCommand(CommandExecuteEvent event) {
        int space;
        String label;
        Player player;
        block7: {
            block6: {
                CommandSource commandSource = event.getCommandSource();
                if (!(commandSource instanceof Player)) break block6;
                player = (Player)commandSource;
                if (event.getResult().isAllowed()) break block7;
            }
            return;
        }
        String command = event.getCommand().strip();
        if (command.startsWith("/")) {
            command = command.substring(1);
        }
        String string = label = (space = command.indexOf(32)) < 0 ? command : command.substring(0, space);
        if (label.isEmpty() || this.isAllowed(player, label)) {
            return;
        }
        event.setResult(CommandExecuteEvent.CommandResult.denied());
        this.messages().send((Audience)player, "blocked", new TagResolver[0]);
    }

    @Subscribe
    public void onTabComplete(TabCompleteEvent event) {
        String partial = event.getPartialMessage();
        if (!partial.startsWith("/") || partial.indexOf(32) >= 0) {
            return;
        }
        Player player = event.getPlayer();
        event.getSuggestions().removeIf(suggestion -> !this.isAllowed(player, suggestion.startsWith("/") ? suggestion.substring(1) : suggestion));
    }

    private static enum Mode {
        WHITELIST,
        BLACKLIST;

    }

    private record Group(String name, String permission, int priority, Mode mode, boolean blockNamespaced, Set<String> commands) {
    }
}
