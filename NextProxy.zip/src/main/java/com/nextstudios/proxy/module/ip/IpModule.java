package com.nextstudios.proxy.module.ip;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.storage.PlayerRepository;
import com.nextstudios.proxy.util.Names;
import com.nextstudios.proxy.util.Pages;
import com.nextstudios.proxy.util.Text;
import com.nextstudios.proxy.util.TimeFormat;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.kyori.adventure.audience.Audience;

public final class IpModule
extends Module {
    private int pageSize;

    public IpModule(NextProxy plugin) {
        super(plugin, "ip");
    }

    @Override
    protected void onEnable() {
        this.pageSize = Math.max(1, this.config().getInt("page-size", 10));
        this.command("ip", spec -> new IpCommand((CommandSpec)spec));
        this.command("iphistory", spec -> new IpHistoryCommand((CommandSpec)spec));
    }

    private final class IpHistoryCommand
    extends BaseCommand {
        IpHistoryCommand(CommandSpec spec) {
            super(IpModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            int page;
            if (args.length < 1 || args.length > 2) {
                this.messages().usage((Audience)source, "iphistory.usage");
                return;
            }
            int n = page = args.length == 2 ? IpHistoryCommand.parsePositive(args[1], -1) : 1;
            if (page < 0) {
                this.messages().send((Audience)source, "general.invalid-number", Text.literal("input", args[1]));
                return;
            }
            String input = args[0];
            if (Names.isIp(input)) {
                this.showAccounts(source, input, page);
                return;
            }
            Optional<Player> online = this.users().find(source, input);
            if (online.isPresent()) {
                this.showHistory(source, online.get().getUniqueId(), this.users().displayName(online.get(), source), page);
                return;
            }
            if (!Names.isValidName(input)) {
                this.messages().send((Audience)source, "general.invalid-name", Text.literal("input", input));
                return;
            }
            ((CompletableFuture)this.plugin.playerRepository().findByName(input).thenAccept(found -> {
                if (found.isEmpty()) {
                    this.messages().send((Audience)source, "general.player-unknown", Text.token("player", input));
                } else {
                    this.showHistory(source, ((PlayerRepository.StoredPlayer)found.get()).uuid(), ((PlayerRepository.StoredPlayer)found.get()).name(), page);
                }
            })).exceptionally(error -> this.fail(source, (Throwable)error));
        }

        private void showHistory(CommandSource source, UUID uuid, String name, int page) {
            ((CompletableFuture)this.plugin.playerRepository().ipHistory(uuid).thenAccept(entries -> {
                if (entries.isEmpty()) {
                    this.messages().send((Audience)source, "iphistory.empty", Text.token("player", name));
                    return;
                }
                TimeFormat time = this.messages().time();
                int current = Pages.clamp(page, entries.size(), IpModule.this.pageSize);
                this.messages().send((Audience)source, "iphistory.header", Text.token("player", name), Text.token("count", entries.size()));
                for (PlayerRepository.IpEntry entry : Pages.slice(entries, current, IpModule.this.pageSize)) {
                    this.messages().send((Audience)source, "iphistory.entry", Text.token("ip", entry.ip()), Text.token("logins", entry.logins()), Text.literal("first", time.date(entry.firstSeen())), Text.literal("last", time.date(entry.lastSeen())));
                }
                this.footer(source, current, entries.size());
            })).exceptionally(error -> this.fail(source, (Throwable)error));
        }

        private void showAccounts(CommandSource source, String ip, int page) {
            ((CompletableFuture)this.plugin.playerRepository().accountsByIp(ip).thenAccept(accounts -> {
                if (accounts.isEmpty()) {
                    this.messages().send((Audience)source, "iphistory.ip-empty", Text.token("ip", ip));
                    return;
                }
                TimeFormat time = this.messages().time();
                int current = Pages.clamp(page, accounts.size(), IpModule.this.pageSize);
                this.messages().send((Audience)source, "iphistory.ip-header", Text.token("ip", ip), Text.token("count", accounts.size()));
                for (PlayerRepository.IpAccount account : Pages.slice(accounts, current, IpModule.this.pageSize)) {
                    this.messages().send((Audience)source, "iphistory.ip-entry", Text.token("player", account.name()), Text.token("logins", account.logins()), Text.literal("last", time.date(account.lastSeen())));
                }
                this.footer(source, current, accounts.size());
            })).exceptionally(error -> this.fail(source, (Throwable)error));
        }

        private void footer(CommandSource source, int page, int total) {
            int pages = Pages.count(total, IpModule.this.pageSize);
            if (pages > 1) {
                this.messages().send((Audience)source, "general.page", Text.token("page", page), Text.token("pages", pages));
            }
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            return args.length <= 1 ? this.users().suggest(source, args.length == 0 ? "" : args[0]) : List.of();
        }
    }

    private final class IpCommand
    extends BaseCommand {
        IpCommand(CommandSpec spec) {
            super(IpModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (args.length != 1) {
                this.messages().usage((Audience)source, "ip.usage");
                return;
            }
            String input = args[0];
            Optional<Player> online = this.users().find(source, input);
            if (online.isPresent()) {
                Player target = online.get();
                this.messages().send((Audience)source, "ip.result", Text.token("player", this.users().displayName(target, source)), Text.token("ip", Names.ipOf(target)));
                return;
            }
            if (!Names.isValidName(input)) {
                this.messages().send((Audience)source, "general.invalid-name", Text.literal("input", input));
                return;
            }
            ((CompletableFuture)this.plugin.playerRepository().findByName(input).thenAccept(found -> {
                if (found.isEmpty() || ((PlayerRepository.StoredPlayer)found.get()).lastIp() == null) {
                    this.messages().send((Audience)source, "general.player-unknown", Text.token("player", input));
                    return;
                }
                this.messages().send((Audience)source, "ip.result-offline", Text.token("player", ((PlayerRepository.StoredPlayer)found.get()).name()), Text.token("ip", ((PlayerRepository.StoredPlayer)found.get()).lastIp()));
            })).exceptionally(error -> this.fail(source, (Throwable)error));
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            return args.length <= 1 ? this.users().suggest(source, args.length == 0 ? "" : args[0]) : List.of();
        }
    }
}
