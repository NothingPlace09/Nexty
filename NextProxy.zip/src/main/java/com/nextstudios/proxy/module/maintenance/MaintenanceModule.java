package com.nextstudios.proxy.module.maintenance;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.ResultedEvent;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.storage.DataRepository;
import com.nextstudios.proxy.module.webhook.WebhookService;
import com.nextstudios.proxy.util.Names;
import com.nextstudios.proxy.util.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class MaintenanceModule
extends Module {
    private static final String STATE_KEY = "maintenance.enabled";
    private static final List<String> SUBCOMMANDS = List.of("on", "off", "add", "remove", "list");
    private final Map<String, DataRepository.WhitelistEntry> whitelist = new ConcurrentHashMap<>();
    private volatile boolean active;
    private String bypassPermission;

    public MaintenanceModule(NextProxy plugin) {
        super(plugin, "maintenance");
    }

    @Override
    protected void onEnable() {
        this.bypassPermission = this.config().getString("bypass-permission", "nextproxy.maintenance.bypass");
        try {

            this.active = this.plugin.dataRepository().get(STATE_KEY).get(10L, TimeUnit.SECONDS).map(Boolean::parseBoolean).orElse(false);
            this.whitelist.clear();
            for (DataRepository.WhitelistEntry entry : this.plugin.dataRepository().whitelist().get(10L, TimeUnit.SECONDS)) {
                this.whitelist.put(entry.name().toLowerCase(Locale.ROOT), entry);
            }
        }
        catch (Exception e) {
            throw new IllegalStateException("Impossibile leggere lo stato della manutenzione dal database", e);
        }
        if (this.active) {
            this.logger().warn("La manutenzione \u00e8 ATTIVA: entrano solo i player in whitelist o con il permesso di bypass");
        }
        this.listen(this);
        this.command("maintenance", spec -> new MaintenanceCommand((CommandSpec)spec));
    }

    public boolean isActive() {
        return this.active;
    }

    public boolean isAllowed(Player player) {
        if (!this.bypassPermission.isEmpty() && player.hasPermission(this.bypassPermission)) {
            return true;
        }
        DataRepository.WhitelistEntry byName = this.whitelist.get(player.getUsername().toLowerCase(Locale.ROOT));
        if (byName != null) {
            if (byName.uuid() == null) {
                this.bindWhitelistEntry(byName, player);
                return true;
            }
            if (byName.uuid().equals(player.getUniqueId())) {
                return true;
            }
        }
        for (DataRepository.WhitelistEntry entry : this.whitelist.values()) {
            if (!player.getUniqueId().equals(entry.uuid())) continue;
            return true;
        }
        return false;
    }

    private void bindWhitelistEntry(DataRepository.WhitelistEntry entry, Player player) {
        DataRepository.WhitelistEntry bound = new DataRepository.WhitelistEntry(player.getUsername(), player.getUniqueId());
        if (!this.whitelist.replace(entry.name().toLowerCase(Locale.ROOT), entry, bound)) {
            return;
        }
        this.plugin.dataRepository().addWhitelist(bound.name(), bound.uuid(), System.currentTimeMillis()).exceptionally(error -> {
            this.logger().error("Impossibile salvare l'UUID di {} nella whitelist", bound.name(), error);
            return null;
        });
    }

    @Subscribe(priority=16383)
    public void onLogin(LoginEvent event) {
        if (this.active && event.getResult().isAllowed() && !this.isAllowed(event.getPlayer())) {
            event.setResult(ResultedEvent.ComponentResult.denied((Component)this.messages().get("kick", new TagResolver[0])));
        }
    }

    private void saveState() {

        this.plugin.dataRepository().set(STATE_KEY, Boolean.toString(this.active)).exceptionally(error -> {
            this.logger().error("Impossibile salvare lo stato della manutenzione", error);
            return null;
        });
    }

    private final class MaintenanceCommand
    extends BaseCommand {
        MaintenanceCommand(CommandSpec spec) {
            super(MaintenanceModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            String sub;
            switch (sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT)) {
                case "on": {
                    this.enable(source);
                    break;
                }
                case "off": {
                    if (!MaintenanceModule.this.active) {
                        this.messages().send((Audience)source, "already-disabled", new TagResolver[0]);
                        return;
                    }
                    MaintenanceModule.this.active = false;
                    MaintenanceModule.this.saveState();
                    this.messages().send((Audience)source, "disabled", new TagResolver[0]);
                    WebhookService hooks = this.plugin.webhooks();
                    if (hooks != null) {
                        hooks.maintenance(this.plugin.nameOf(source), false, 0);
                    }
                    break;
                }

                case "add": {
                    if (args.length != 2) {
                        this.messages().usage((Audience)source, "usage");
                        break;
                    }
                    this.add(source, args[1]);
                    break;
                }
                case "remove": {
                    if (args.length != 2) {
                        this.messages().usage((Audience)source, "usage");
                        break;
                    }
                    this.remove(source, args[1]);
                    break;
                }
                case "list": {
                    this.list(source);
                    break;
                }
                default: {
                    this.messages().usage((Audience)source, "usage");
                }
            }
        }

        private void enable(CommandSource source) {
            if (MaintenanceModule.this.active) {
                this.messages().send((Audience)source, "already-enabled", new TagResolver[0]);
                return;
            }
            MaintenanceModule.this.active = true;
            MaintenanceModule.this.saveState();
            Component kick = this.messages().get("kick", new TagResolver[0]);
            int kicked = 0;
            for (Player player : MaintenanceModule.this.proxy().getAllPlayers()) {
                if (MaintenanceModule.this.isAllowed(player)) continue;
                player.disconnect(kick);
                ++kicked;
            }
            this.messages().send((Audience)source, "enabled", Text.token("kicked", kicked));
            MaintenanceModule.this.logger().info("Manutenzione attivata da {} ({} player espulsi)", (Object)this.plugin.nameOf(source), (Object)kicked);
            WebhookService hooks = this.plugin.webhooks();
            if (hooks != null) {
                hooks.maintenance(this.plugin.nameOf(source), true, kicked);
            }
        }

        private void add(CommandSource source, String name) {
            if (!Names.isValidName(name)) {
                this.messages().send((Audience)source, "general.invalid-name", Text.literal("input", name));
                return;
            }
            if (MaintenanceModule.this.whitelist.containsKey(name.toLowerCase(Locale.ROOT))) {
                this.messages().send((Audience)source, "already-added", Text.token("player", name));
                return;
            }
            Player online = MaintenanceModule.this.proxy().getPlayer(name).orElse(null);
            CompletionStage<DataRepository.WhitelistEntry> resolve = online != null ? CompletableFuture.completedFuture(new DataRepository.WhitelistEntry(online.getUsername(), online.getUniqueId())) : this.plugin.playerRepository().findByName(name).thenApply(found -> found.map(stored -> new DataRepository.WhitelistEntry(stored.name(), stored.uuid())).orElse(new DataRepository.WhitelistEntry(name, null)));
            resolve.thenCompose(entry -> this.plugin.dataRepository().addWhitelist(entry.name(), entry.uuid(), System.currentTimeMillis()).thenApply(ignored -> entry)).thenAccept(entry -> {
                MaintenanceModule.this.whitelist.put(entry.name().toLowerCase(Locale.ROOT), entry);
                this.messages().send((Audience)source, "added", Text.token("player", entry.name()));
            }).exceptionally(error -> this.fail(source, (Throwable)error));
        }

        private void remove(CommandSource source, String name) {
            String key = name.toLowerCase(Locale.ROOT);
            DataRepository.WhitelistEntry entry = MaintenanceModule.this.whitelist.get(key);
            if (entry == null) {
                this.messages().send((Audience)source, "not-added", Text.token("player", name));
                return;
            }
            this.plugin.dataRepository().removeWhitelist(entry.name()).thenAccept(removed -> {
                MaintenanceModule.this.whitelist.remove(key);
                this.messages().send((Audience)source, "removed", Text.token("player", entry.name()));
            }).exceptionally(error -> this.fail(source, (Throwable)error));
        }

        private void list(CommandSource source) {
            ArrayList<DataRepository.WhitelistEntry> entries = new ArrayList<DataRepository.WhitelistEntry>(MaintenanceModule.this.whitelist.values());
            entries.sort((a, b) -> a.name().compareToIgnoreCase(b.name()));
            this.messages().send((Audience)source, "list-header", Text.component("status", this.messages().get(MaintenanceModule.this.active ? "status-on" : "status-off", new TagResolver[0])), Text.token("count", entries.size()));
            if (entries.isEmpty()) {
                this.messages().send((Audience)source, "list-empty", new TagResolver[0]);
                return;
            }
            for (DataRepository.WhitelistEntry entry : entries) {
                this.messages().send((Audience)source, "list-entry", Text.token("player", entry.name()));
            }
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length <= 1) {
                return MaintenanceCommand.filter(SUBCOMMANDS, args.length == 0 ? "" : args[0]);
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("add")) {
                return this.users().suggest(source, args[1]);
            }
            if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
                ArrayList<String> names = new ArrayList<String>();
                for (DataRepository.WhitelistEntry entry : MaintenanceModule.this.whitelist.values()) {
                    names.add(entry.name());
                }
                return MaintenanceCommand.filter(names, args[1]);
            }
            return List.of();
        }
    }
}
