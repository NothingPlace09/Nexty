package com.nextstudios.proxy.module.teleport;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ServerConnection;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.util.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.kyori.adventure.audience.Audience;

public final class GotoModule
extends Module {
    private boolean perServerPermission;
    private boolean allowPlayerTarget;

    public GotoModule(NextProxy plugin) {
        super(plugin, "goto");
    }

    @Override
    protected void onEnable() {
        this.perServerPermission = this.config().getBoolean("per-server-permission", false);
        this.allowPlayerTarget = this.config().getBoolean("allow-player-target", true);
        this.command("goto", spec -> new GotoCommand((CommandSpec)spec));
    }

    private final class GotoCommand
    extends BaseCommand {
        GotoCommand(CommandSpec spec) {
            super(GotoModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            Optional<Player> other;
            Player player = this.requirePlayer(source);
            if (player == null) {
                return;
            }
            if (args.length != 1) {
                this.messages().usage((Audience)source, "usage");
                return;
            }
            String input = args[0];
            RegisteredServer target = GotoModule.this.proxy().getServer(input).orElse(null);
            if (target == null && GotoModule.this.allowPlayerTarget && (other = this.users().find((CommandSource)player, input)).isPresent() && (target = (RegisteredServer)other.get().getCurrentServer().map(ServerConnection::getServer).orElse(null)) == null) {
                this.messages().send((Audience)source, "player-no-server", Text.token("player", this.users().displayName(other.get(), (CommandSource)player)));
                return;
            }
            if (target == null) {
                this.messages().send((Audience)source, "general.server-not-found", Text.token("server", input));
                return;
            }
            String name = target.getServerInfo().getName();
            if (GotoModule.this.perServerPermission && !player.hasPermission("NextProxy.goto.server." + name.toLowerCase(Locale.ROOT))) {
                this.messages().send((Audience)source, "no-permission-server", Text.token("server", name));
                return;
            }
            RegisteredServer destination = target;
            if (player.getCurrentServer().map(connection -> connection.getServer().equals((Object)destination)).orElse(false).booleanValue()) {
                this.messages().send((Audience)source, "already-connected", Text.token("server", name));
                return;
            }
            this.messages().send((Audience)source, "connecting", Text.token("server", name));
            player.createConnectionRequest(destination).fireAndForget();
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length > 1) {
                return List.of();
            }
            String input = args.length == 0 ? "" : args[0];
            ArrayList<String> options = new ArrayList<String>();
            for (RegisteredServer server : GotoModule.this.proxy().getAllServers()) {
                options.add(server.getServerInfo().getName());
            }
            List<String> result = GotoCommand.filter(options, input);
            if (GotoModule.this.allowPlayerTarget) {
                result.addAll(this.users().suggest(source, input));
            }
            return result;
        }
    }
}
