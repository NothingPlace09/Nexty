package com.nextstudios.proxy.module.disguise;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.proxy.Player;
import com.nextstudios.proxy.NextProxy;
import com.nextstudios.proxy.command.BaseCommand;
import com.nextstudios.proxy.command.CommandSpec;
import com.nextstudios.proxy.module.Module;
import com.nextstudios.proxy.module.disguise.SkinService;
import com.nextstudios.proxy.user.Disguise;
import com.nextstudios.proxy.user.Skin;
import com.nextstudios.proxy.user.User;
import com.nextstudios.proxy.util.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;

public final class DisguiseModule
extends Module {
    private static final Pattern DISGUISE_NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static final int ATTEMPTS = 25;
    private String customPermission;
    private String listPermission;
    private boolean persist;
    private boolean avoidExisting;
    private List<String> fixedNames;
    private List<String> prefixes;
    private List<String> suffixes;
    private boolean generate;
    private int maxNumber;
    private SkinService skins;

    public DisguiseModule(NextProxy plugin) {
        super(plugin, "disguise");
    }

    @Override
    protected void onEnable() {
        this.customPermission = this.config().getString("custom-name-permission", "NextProxy.disguise.custom");
        this.listPermission = this.config().getString("list-permission", "NextProxy.disguise.list");
        this.persist = this.config().getBoolean("persist", true);
        this.avoidExisting = this.config().getBoolean("avoid-existing-players", true);
        this.fixedNames = this.validNames(this.config().getStringList("names.list"));
        this.generate = this.config().getBoolean("names.generate", true);
        this.prefixes = this.config().getStringList("names.prefixes");
        this.suffixes = this.config().getStringList("names.suffixes");
        this.maxNumber = Math.max(0, this.config().getInt("names.max-number", 99));
        this.skins = new SkinService(this.plugin);
        this.skins.load(this.config().getStringList("skins.from-players"), this.readTextures(), this.config().getLong("skins.cache-hours", 72L));
        this.listen(this);
        this.command("disguise", spec -> new DisguiseCommand((CommandSpec)spec));
        this.command("undisguise", spec -> new UndisguiseCommand((CommandSpec)spec));
        this.command("realname", spec -> new RealNameCommand((CommandSpec)spec));
    }

    @Override
    protected void onDisable() {
        if (this.skins != null) {
            this.skins.close();
        }
    }

    private List<String> validNames(List<String> names) {
        ArrayList<String> result = new ArrayList<String>();
        for (String name : names) {
            if (DISGUISE_NAME.matcher(name).matches()) {
                result.add(name);
                continue;
            }
            this.logger().warn("Disguise: il nick '{}' non \u00e8 valido (3-16 caratteri, lettere, numeri e _)", (Object)name);
        }
        return List.copyOf(result);
    }

    private List<Skin> readTextures() {
        ArrayList<Skin> result = new ArrayList<Skin>();
        for (Object entry : this.config().getList("skins.textures")) {
            Map map;
            if (!(entry instanceof Map) || (map = (Map)entry).get("value") == null || String.valueOf(map.get("value")).isBlank()) continue;
            Object signature = map.get("signature");
            result.add(new Skin(String.valueOf(map.get("value")).trim(), signature == null ? null : String.valueOf(signature).trim()));
        }
        return result;
    }

    private String randomCandidate() {
        boolean canGenerate;
        ThreadLocalRandom random = ThreadLocalRandom.current();
        boolean bl = canGenerate = this.generate && !this.prefixes.isEmpty() && !this.suffixes.isEmpty();
        if (!(this.fixedNames.isEmpty() || canGenerate && !random.nextBoolean())) {
            return this.fixedNames.get(random.nextInt(this.fixedNames.size()));
        }
        if (!canGenerate) {
            return null;
        }
        String base = this.prefixes.get(random.nextInt(this.prefixes.size())) + this.suffixes.get(random.nextInt(this.suffixes.size()));
        if (this.maxNumber > 0) {
            base = base + random.nextInt(this.maxNumber + 1);
        }
        return base.length() > 16 ? base.substring(0, 16) : base;
    }

    private boolean availableLocally(String name, Player owner) {
        if (!DISGUISE_NAME.matcher(name).matches()) {
            return false;
        }
        Player real = this.proxy().getPlayer(name).orElse(null);
        if (real != null && !real.equals((Object)owner)) {
            return false;
        }
        Player holder = this.users().byDisguiseName(name).orElse(null);
        return holder == null || holder.equals((Object)owner);
    }

    private CompletableFuture<Boolean> available(String name, Player owner) {
        if (!this.availableLocally(name, owner)) {
            return CompletableFuture.completedFuture(false);
        }
        return this.plugin.disguiseRepository().isNameTaken(name, owner.getUniqueId(), this.avoidExisting).thenApply(taken -> taken == false);
    }

    private CompletableFuture<String> generateName(Player owner, int attempts) {
        String candidate;
        String string = candidate = attempts <= 0 ? null : this.randomCandidate();
        if (candidate == null) {
            return CompletableFuture.completedFuture(null);
        }
        return this.available(candidate, owner).thenCompose(free -> free != false ? CompletableFuture.completedFuture(candidate) : this.generateName(owner, attempts - 1));
    }

    private void disguise(Player player, String requested) {
        CompletionStage<String> name;
        if (requested == null) {
            name = this.generateName(player, 25);
        } else {
            if (!DISGUISE_NAME.matcher(requested).matches()) {
                this.messages().send((Audience)player, "general.invalid-name", Text.literal("input", requested));
                return;
            }
            name = this.available(requested, player).thenApply(free -> free != false ? requested : "");
        }
        ((CompletableFuture)name.thenAccept(chosen -> {
            if (chosen == null) {
                this.messages().send((Audience)player, "no-name-available", new TagResolver[0]);
                return;
            }
            if (chosen.isEmpty()) {
                this.messages().send((Audience)player, "name-taken", Text.token("name", requested));
                return;
            }
            if (!this.apply(player, new Disguise((String)chosen, this.skins.random().orElse(null)))) {
                if (player.isActive()) {
                    this.messages().send((Audience)player, "name-taken", Text.token("name", chosen));
                }
                return;
            }
            this.messages().send((Audience)player, "disguised", Text.token("name", chosen));
            this.plugin.bridge().warnIfMissing(player, "no-bridge");
        })).exceptionally(error -> {
            this.logger().error("Errore durante il disguise di {}", (Object)player.getUsername(), error);
            this.messages().send((Audience)player, "general.error", new TagResolver[0]);
            return null;
        });
    }

    private boolean apply(Player player, Disguise disguise) {
        User user = this.users().get(player);
        if (!this.users().setDisguise(user, disguise)) {
            return false;
        }
        if (this.persist) {
            CompletableFuture<Void> save = disguise == null ? this.plugin.disguiseRepository().delete(player.getUniqueId()) : this.plugin.disguiseRepository().save(player.getUniqueId(), disguise, System.currentTimeMillis());
            save.exceptionally(error -> {
                this.logger().error("Impossibile salvare il disguise di {}", (Object)player.getUsername(), error);
                return null;
            });
        }
        this.plugin.bridge().push(player);
        return true;
    }

    private void undisguise(Player player) {
        if (this.users().get(player).disguise() == null) {
            this.messages().send((Audience)player, "not-disguised", new TagResolver[0]);
            return;
        }
        this.apply(player, null);
        this.messages().send((Audience)player, "undisguised", Text.token("player", player.getUsername()));
    }

    private void reroll(Player holder, String oldName) {
        ((CompletableFuture)this.generateName(holder, 25).thenAccept(name -> {
            if (name == null) {
                this.apply(holder, null);
                this.messages().send((Audience)holder, "undisguised", Text.token("player", holder.getUsername()));
                return;
            }
            Disguise old = this.users().get(holder).disguise();
            Skin skin = old != null && old.skin() != null ? old.skin() : this.skins.random().orElse(null);
            if (!this.apply(holder, new Disguise((String)name, skin))) {
                if (holder.isActive()) {
                    this.reroll(holder, oldName);
                }
                return;
            }
            this.messages().send((Audience)holder, "rerolled", Text.token("name", oldName), Text.token("new", name));
        })).exceptionally(error -> {
            this.logger().error("Errore cambiando il disguise di {}", (Object)holder.getUsername(), error);
            return null;
        });
    }

    @Subscribe
    public void onPostLogin(PostLoginEvent event) {
        Player joined = event.getPlayer();
        this.users().byDisguiseName(joined.getUsername()).filter(holder -> !holder.equals((Object)joined)).ifPresent(holder -> this.reroll((Player)holder, joined.getUsername()));
        Disguise own = this.users().get(joined).disguise();
        if (own != null) {
            this.proxy().getPlayer(own.name()).filter(real -> !real.equals((Object)joined)).ifPresent(real -> this.reroll(joined, own.name()));
        }
    }

    private void list(CommandSource source) {
        ArrayList<Player> disguised = new ArrayList<Player>();
        for (Player player : this.proxy().getAllPlayers()) {
            if (this.users().get(player).disguise() == null) continue;
            disguised.add(player);
        }
        if (disguised.isEmpty()) {
            this.messages().send((Audience)source, "list-empty", new TagResolver[0]);
            return;
        }
        this.messages().send((Audience)source, "list-header", Text.token("count", disguised.size()));
        for (Player player : disguised) {
            Disguise disguise = this.users().get(player).disguise();
            if (disguise == null) continue;
            this.messages().send((Audience)source, "list-entry", Text.token("player", player.getUsername()), Text.token("name", disguise.name()));
        }
    }

    private final class RealNameCommand
    extends BaseCommand {
        RealNameCommand(CommandSpec spec) {
            super(DisguiseModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (args.length != 1) {
                this.messages().usage((Audience)source, "realname-usage");
                return;
            }
            this.users().byDisguiseName(args[0]).ifPresentOrElse(real -> this.messages().send((Audience)source, "realname", Text.token("name", this.users().get((Player)real).disguise().name()), Text.token("player", real.getUsername())), () -> this.messages().send((Audience)source, "realname-none", Text.token("name", args[0])));
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length > 1) {
                return List.of();
            }
            ArrayList<String> names = new ArrayList<String>();
            for (Player player : DisguiseModule.this.proxy().getAllPlayers()) {
                Disguise disguise = this.users().get(player).disguise();
                if (disguise == null) continue;
                names.add(disguise.name());
            }
            return RealNameCommand.filter(names, args.length == 0 ? "" : args[0]);
        }
    }

    private final class UndisguiseCommand
    extends BaseCommand {
        UndisguiseCommand(CommandSpec spec) {
            super(DisguiseModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            Player player = this.requirePlayer(source);
            if (player != null) {
                DisguiseModule.this.undisguise(player);
            }
        }
    }

    private final class DisguiseCommand
    extends BaseCommand {
        DisguiseCommand(CommandSpec spec) {
            super(DisguiseModule.this, spec);
        }

        @Override
        protected void execute(CommandSource source, String[] args) {
            if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
                if (!DisguiseModule.this.listPermission.isEmpty() && !source.hasPermission(DisguiseModule.this.listPermission)) {
                    this.messages().send((Audience)source, "general.no-permission", new TagResolver[0]);
                } else {
                    DisguiseModule.this.list(source);
                }
                return;
            }
            Player player = this.requirePlayer(source);
            if (player == null) {
                return;
            }
            if (args.length == 0) {
                DisguiseModule.this.disguise(player, null);
            } else if (args.length == 1) {
                if (!DisguiseModule.this.customPermission.isEmpty() && !player.hasPermission(DisguiseModule.this.customPermission)) {
                    this.messages().send((Audience)source, "general.no-permission", new TagResolver[0]);
                } else {
                    DisguiseModule.this.disguise(player, args[0]);
                }
            } else {
                this.messages().usage((Audience)source, "usage");
            }
        }

        @Override
        protected List<String> suggest(CommandSource source, String[] args) {
            if (args.length <= 1 && (DisguiseModule.this.listPermission.isEmpty() || source.hasPermission(DisguiseModule.this.listPermission))) {
                return DisguiseCommand.filter(List.of("list"), args.length == 0 ? "" : args[0]);
            }
            return List.of();
        }
    }
}
