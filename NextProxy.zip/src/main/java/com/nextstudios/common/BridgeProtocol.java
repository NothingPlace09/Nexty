package com.nextstudios.common;

public final class BridgeProtocol {
    public static final String NAMESPACE = "nextstudios";
    public static final String NAME = "bridge";
    public static final String CHANNEL = "nextstudios:bridge";
    public static final String STATE_PROPERTY = "nextstudios_state";
    public static final int VERSION = 1;
    public static final int STATE = 1;
    public static final int HELLO = 64;
    public static final int STAFF_CHAT = 65;
    public static final int REQUEST_SYNC = 69;

    private BridgeProtocol() {
    }
}
