package com.nextstudios.common;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.UUID;

public record PlayerState(UUID uuid, int flags, String disguiseName, String skinValue, String skinSignature) {
    public static final int STAFF_CHAT = 1;

    public static PlayerState empty(UUID uuid) {
        return new PlayerState(uuid, 0, null, null, null);
    }

    public boolean has(int flag) {
        return (this.flags & flag) != 0;
    }

    public boolean staffChat() {
        return this.has(1);
    }

    public boolean disguised() {
        return this.disguiseName != null;
    }

    public void write(DataOutputStream out) throws IOException {
        out.writeLong(this.uuid.getMostSignificantBits());
        out.writeLong(this.uuid.getLeastSignificantBits());
        out.writeInt(this.flags);
        PlayerState.writeNullable(out, this.disguiseName);
        PlayerState.writeNullable(out, this.skinValue);
        PlayerState.writeNullable(out, this.skinSignature);
    }

    public static PlayerState read(DataInputStream in) throws IOException {
        UUID uuid = new UUID(in.readLong(), in.readLong());
        int flags = in.readInt();
        String name = PlayerState.readNullable(in);
        String value = PlayerState.readNullable(in);
        String signature = PlayerState.readNullable(in);
        if (name != null && (name.isEmpty() || name.length() > 16)) {
            throw new IOException("nick del disguise non valido");
        }
        return new PlayerState(uuid, flags, name, value, signature);
    }

    private static void writeNullable(DataOutputStream out, String value) throws IOException {
        out.writeBoolean(value != null);
        if (value != null) {
            out.writeUTF(value);
        }
    }

    private static String readNullable(DataInputStream in) throws IOException {
        return in.readBoolean() ? in.readUTF() : null;
    }
}
