package com.nextstudios.common;

import java.security.SecureRandom;
import java.util.Base64;

public final class BridgeSecret {
    public static final int MIN_LENGTH = 16;
    private static final int GENERATED_LENGTH = 32;

    private BridgeSecret() {
    }

    public static byte[] generate() {
        byte[] secret = new byte[32];
        new SecureRandom().nextBytes(secret);
        return secret;
    }

    public static String encode(byte[] secret) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(secret);
    }

    public static byte[] decode(String text) {
        byte[] decoded;
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("segreto vuoto");
        }
        String trimmed = text.trim();
        try {
            decoded = Base64.getUrlDecoder().decode(trimmed);
        }
        catch (IllegalArgumentException urlSafeFailed) {
            decoded = Base64.getDecoder().decode(trimmed);
        }
        if (decoded.length < 16) {
            throw new IllegalArgumentException("segreto troppo corto (minimo 16 byte)");
        }
        return decoded;
    }
}
